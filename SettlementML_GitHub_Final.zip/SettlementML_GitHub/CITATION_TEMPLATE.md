# Citation information to complete before publication

Use the authorship, article title and publication identifier actually approved for this research. No DOI or publication acceptance is inferred from this repository.

Suggested fields for the eventual citation:

```text
Authors: [approved author list]
Title: [actual article / software release title]
Year: [actual publication year]
Repository: [actual public URL]
Version: SettlementML 1.0.0
DOI: [omit until a real DOI exists]
```

This is an editorial template, not a valid bibliographic record. Once confirmed, add a valid `CITATION.cff` rather than copying placeholders into one.
