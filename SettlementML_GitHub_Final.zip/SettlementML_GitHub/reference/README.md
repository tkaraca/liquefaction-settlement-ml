# Reference outputs: historical and newly executed results

## Historical artifacts

`archived_core_oof.csv`, `archived_report_metrics.csv`, `archived_ann_core_summary.csv` and `archived_external_predictions.csv` are recovered source artifacts. They are not presented as experiments newly executed with the released CV seeds. External predictions in the old CSV are rounded to four decimal places.

## Release execution results

| Folder | Contents |
|---|---|
| release_validation | New deterministic GroupKFold point metrics, OOF rows, fold audit, nested residual-band check, all figures |
| release_predictions | Frozen model predictions for all 14 external buildings |
| release_external | All-case evaluation, numeric-reference masks, tolerance rates and observed coverage, all complete-case figures |
| release_ablation_features | 12 feature-representation configurations, OOFs and exploratory group-bootstrap paired differences |
| release_ablation_targets | 8 raw/compressed/weighted core ExtraTrees variants |
| release_ablation_ann | 8 core-input ANN architecture/transformation variants; convergence warnings preserved |
| release_ablation_families | 10 core-input family variants, including actually executed XGBoost/LightGBM/CatBoost |
| release_coefficients | Linear/hinge ridge OOFs, complete coefficients, executable formula and export check |
| checks | Data/source checks, point-model reproduction, local tests and execution logs |

All ablations use the release split/seed protocol. Suites overlap in the core/raw/unweighted reference; totals across suites are not independent methods. Runtimes in resumed ANN status entries describe cache reuse for that invocation, not full model fitting duration. See execution markers and logs.

Open `release_validation/report.html` or `release_external/report.html` in a browser for an offline gallery. Each PNG has an SVG counterpart. CSV files are the numerical source, not values reconstructed from charts.

New exploratory comparisons can improve particular metrics without changing the frozen default. They should not be retroactively substituted into historical manuscript tables without corresponding model-selection and documentation updates.
