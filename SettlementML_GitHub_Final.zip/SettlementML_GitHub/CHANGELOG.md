# Changelog

## 1.0.0: consolidated research release

This release consolidates the existing research artifacts into a reproducible CLI and run-button repository. It does not silently overwrite the archived scientific record.

### Preserved

- Frozen raw/unweighted core-input ExtraTrees point estimator and its archived classifier.
- Source development and external data values, with source hashes and observation-status annotations.
- Historical OOF results, ANN summary and rounded external predictions, clearly labeled as archived references.
- Nonnegative settlement components, maximum-displacement reconstruction and formula-derived rotation.

### Corrected / made explicit

1. **Estimator count and seed:** actual fitted model is 60 trees / 1777, not the 500 / 777 settings in the old training wrapper. The fitted object is the source of truth for the default configuration.
2. **Retained analysis groups:** 2325 valid building rows contain 1099 distinct AnalizNo values. 1120 refers to the original simulation program, not the retained group count.
3. **Classifier naming:** the archived model called `upper_response` actually learned T>5°. It is now `high_response`. The q90-union subset remains distinct.
4. **Band key lookup:** `upper_response` residual quantiles are read explicitly; invalid fallback from nonexistent `upper/nonupper` keys is removed.
5. **Delta interval:** added as a separately calibrated diagnostic from archived delta OOF errors. Other archived quantiles remain unchanged.
6. **Scope checks:** marginal bounds, unseen levels, unsupported joint geometry/loading, three-building Df support and heterogeneous-neighbor notes are separated. Nonzero physical spacing is never silently changed to a different scenario class.
7. **Observed zeros:** uncertain 0/0/0 entries remain visible and are not used as confirmed zero targets. No post-hoc exclusion based on poor prediction is performed.
8. **Figures:** every chosen interacting case includes all buildings. Independent single buildings are not made into an interacting group because they share a field CaseID.
9. **Calibration evidence:** same-OOF residual quantile coverage is labeled diagnostic. Optional nested group band evaluation is available.
10. **Coefficient model:** accurately named quantile-knot additive linear-spline regression with ridge penalty. Full standardized and raw-basis equations are exported; not MARS and not knowledge distillation.

### New reproducible experiments

Fold-specific seeds are now recorded. Historical OOF training seeds were not fully recorded; current reruns are not advertised as identical historical repetitions. ANN training uses a fixed budget with early_stopping=False to avoid a hidden random row validation split. Family benchmarks, target transformations and paired feature comparisons produce fresh labeled run artifacts. New exploratory ablation results do not automatically replace the frozen default model or imply a new globally optimal method.

### Packaging

CSV/XLSX input, UTF-8 tables, PNG/SVG figures, HTML gallery, single configuration, English/Turkish README, tests, Windows/Linux CI definition, source SHA256 manifest, complete-case example templates and publication checklist.
