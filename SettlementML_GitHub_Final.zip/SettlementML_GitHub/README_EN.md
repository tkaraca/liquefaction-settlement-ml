# SettlementML: English quick start

A reproducible research repository for building-level settlement and rotation prediction. The frozen model is an **unweighted, raw-target ExtraTrees regressor with core inputs**. It predicts minimum settlement and differential settlement. Maximum settlement and rotation are reconstructed:

```text
delta = uy_max - uy_min
uy_max_pred = uy_min_pred + delta_pred
T_pred = degrees(atan(delta_pred / (100 * B_m)))
```

Displacements are in cm; B is in m. No arbitrary upper clipping is applied. This repository provides research estimates, not a certified structural-safety decision.

## Installation

Use a separate Python 3.13 environment. The release was tested locally with Python 3.13.5 on Linux. Python 3.11–3.13 is supported by the package specification; Windows/Linux CI definitions are provided, but remote CI has not been executed during preparation.

Windows PowerShell, from the folder containing this README:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m settlementml doctor
```

Linux/macOS:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m settlementml doctor
```

Activation is optional. In subsequent commands use your environment's Python executable instead of `python` where necessary. Load joblib files only from trusted sources, with the pinned library versions.

## Predict immediately using the frozen model

```bash
python -m settlementml predict --input data/examples/Input_Template.xlsx --sheet Inputs --model models/final.joblib --out outputs/demo
python -m settlementml figures --run outputs/demo
```

The filled Excel/CSV examples come from development records; they demonstrate the interface and are not independent validation. Replace them with your own inputs. Use one row per building, a common CaseID for an interacting system, and distinct BuildingID/position values. Two-building systems require left/right; three-building systems require left/middle/right. Complete-case plots retain all building positions.

Outputs: `predictions.csv`, `prediction_audit.json`, PNG/SVG figures and `report.html`. Prediction does not require observed output values. No Excel application, GPU or office-conversion tool is required.

## Reproduce the full workflow

```bash
python -m settlementml preprocess --input data/training_qc.csv --out outputs/preprocessed
python -m settlementml validate --input outputs/preprocessed/training_long.csv --out outputs/validation
python -m settlementml train --input outputs/preprocessed/training_long.csv --validation outputs/validation --out outputs/models/final.joblib
python -m settlementml predict --input data/examples/external_cases.csv --model outputs/models/final.joblib --out outputs/external_predictions
python -m settlementml evaluate --predictions outputs/external_predictions/predictions.csv --out outputs/external
python -m settlementml figures --run outputs/validation
python -m settlementml figures --run outputs/external
```

Equivalent one-command workflow:

```bash
python -m settlementml all --out outputs/full_run
```

`all` does not run the longer ablations. Add `--nested-bands` to check bands using calibration produced exclusively within the training groups of each outer fold.

## Experiments

```bash
python -m settlementml ablation --suite features --out outputs/ablation_features
python -m settlementml ablation --suite targets --out outputs/ablation_targets
python -m settlementml ablation --suite ann --out outputs/ablation_ann
python -m pip install -r requirements-optional.txt
python -m settlementml ablation --suite families --out outputs/ablation_families
python -m settlementml figures --run outputs/ablation_features
```

Use `--resume` with the same output folder/configuration after interruption. All model families are not automatically selected or promoted to the frozen model. These are exploratory comparisons. They do not prove that the frozen model is universally optimal.

For coefficient-based baselines and a complete executable formula:

```bash
python -m settlementml coefficients --out outputs/coefficients
python -m settlementml formula-predict --input data/examples/prediction_long.csv --formula outputs/coefficients/formula.json --out outputs/formula_predictions.csv
```

The baseline is **additive piecewise-linear regression with quantile knots and an L2/ridge penalty**, not adaptive MARS and not distillation of ExtraTrees. All coefficients, knot values, basis means/scales and an export consistency check are provided.

## Important distinctions

- The archived fitted point model contains **60 trees, seed 1777**. A previous wrapper claimed 500 trees/seed 777; the current configuration follows the fitted model. Details are in [CHANGELOG.md](CHANGELOG.md).
- Data: **2325 building records and 1099 retained analysis groups**. The original simulation program's 1120 analysis identifiers are not the retained group count.
- The frozen auxiliary classifier predicts **T > 5°**, not the union of the top-decile rotation/displacement responses. The latter is a separate descriptive subset and residual pool. Probabilities are not calibrated structural-risk probabilities.
- Residual bands fitted and evaluated on the same OOF residuals are calibration diagnostics, not independent 90% coverage validation. External coverage is computed as observed, without selecting only well-predicted buildings.
- `observed_status=non-observable` or `unknown` retains predictions but excludes uncertain reference values from numeric error aggregation. Numeric zeros are not removed merely for being zero.
- B has only 9 and 12 m support in the development design; H/B ranges from 1 to 2. Larger widths and unsupported joint input combinations are reported, not silently changed. An in-range marginal value does not establish in-distribution validity.

## Tests and reference results

```bash
python -m pip install -r requirements-dev.txt
python -m pytest
python -m settlementml reference-check
python scripts/verify_release.py
```

Historical OOF metrics and newly executed release results are separated under `reference/`. Recomputing historical metrics is not a claim of recovering the original fold-specific fitting seeds. [Reproducibility details](docs/REPRODUCIBILITY.md).

## Documentation and publication

- [Full Turkish README](README.md)
- [Data dictionary](docs/DATA_SCHEMA.md)
- [Model card and limitations](docs/MODEL_CARD.md)
- [Reproducibility and execution provenance](docs/REPRODUCIBILITY.md)
- [Publication checklist](docs/PUBLICATION_CHECKLIST.md)

Upload the repository contents, not only a ZIP archive. Obtain the research team's approval for data/model redistribution and complete the license/citation information before public release. No data license, author list, DOI or repository URL has been invented in this package.
