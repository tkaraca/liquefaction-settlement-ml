from copy import deepcopy
from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from settlementml.data import prepare_inputs,training_table,INPUTS,CORE,features_for,scope_warnings,range_metadata
from settlementml.io import read_table,read_json,write_table
from settlementml.models import transform_targets,inverse_targets,reconstruct,load_bundle,predict_bundle
from settlementml.metrics import observed_reference,coverage_metrics
from settlementml.workflows import preprocess,validate,train,predict,evaluate,frame_signature


@pytest.fixture
def cases():return read_table(ROOT/'data/examples/external_cases.csv')

@pytest.fixture
def config():return read_json(ROOT/'configs/final.json')

@pytest.fixture
def training():return training_table(read_table(ROOT/'data/training_qc.csv'))[0]


def test_final_schema_has_no_target_ids():
    assert not set(CORE)&{'uy_min_cm','uy_max_cm','uy_fark_cm','T_deg','AnalizNo','CaseID','BuildingID','RecordID'}
    assert 'w_over_B' not in features_for('core')
    assert 'w_over_B' in features_for('selected')


def test_basement_convention(cases):
    d,_=prepare_inputs(cases)
    assert d.loc[d.Df_m==3,'BodrumDurumu'].eq('Bodrumlu').all()
    assert d.loc[d.Df_m==1,'BodrumDurumu'].eq('Bodrumsuz').all()


def test_invalid_basement_rejected(cases):
    cases.loc[0,'Df_m']=2
    with pytest.raises(ValueError,match='Df_m'):prepare_inputs(cases)


def test_bad_profile_rejected(cases):
    cases.loc[0,'ProfilNo']='P3'
    with pytest.raises(ValueError,match='ProfilNo'):prepare_inputs(cases)


def test_typographic_right_is_normalized(cases):
    cases.loc[cases.BinaKonumu=='Sag Bina','BinaKonumu']='Sağ Bina'
    d,_=prepare_inputs(cases)
    assert d.BinaKonumu.isin(['Sol Bina','Orta Bina','Sag Bina']).all()


def test_missing_detached_spacing_not_silently_zero(cases):
    cases.loc[0,'w_m']=np.nan
    with pytest.raises(ValueError,match='Missing w_m'):prepare_inputs(cases)


def test_physical_gap_does_not_relabel_adjacent(cases):
    cases['w_m'] = cases['w_m'].astype(float)
    cases.loc[cases.Senaryo.str.contains('Bitişik'),'w_m']=.5
    with pytest.raises(ValueError,match='model code'):prepare_inputs(cases)


def test_missing_single_spacing_can_use_code(cases):
    cases.loc[cases.BuildingID.eq('C35'),'w_m']=np.nan
    d,events=prepare_inputs(cases)
    assert d.loc[d.BuildingID.eq('C35'),'w_m'].iloc[0]==0
    assert any(e['field']=='w_m' for e in events)


def test_h_b_reconstructed_and_inconsistent_fails(cases):
    expected=cases.H_m/cases.B_m
    cases['H_B']=np.nan
    d,_=prepare_inputs(cases)
    np.testing.assert_allclose(d.H_B,expected)
    cases.loc[0,'H_B']=9
    with pytest.raises(ValueError,match='H_B'):prepare_inputs(cases)


def test_nonpositive_width_fails(cases):
    cases.loc[0,'B_m']=0
    with pytest.raises(ValueError,match='B_m'):prepare_inputs(cases)


def test_two_buildings_no_middle(cases):
    cases.loc[0,'BinaKonumu']='Orta Bina'
    with pytest.raises(ValueError,match='Invalid position'):prepare_inputs(cases)


def test_complete_multibuilding_case_required(cases):
    with pytest.raises(ValueError,match='Incomplete'):prepare_inputs(cases[cases.BuildingID!='C23'])


def test_independent_singles_not_confused_with_three(cases):
    d,_=prepare_inputs(cases)
    s=d[d.BuildingID.isin(['C34','C35','C36'])]
    assert s.BinaSayisi.eq(1).all()


def test_wide_expands_one_two_three():
    w=read_table(ROOT/'data/examples/prediction_wide.csv')
    d,_=prepare_inputs(w,fmt='wide')
    assert len(d)==6
    assert d.groupby('CaseID').size().tolist()==[1,2,3]


def test_wide_observed_cannot_be_copied_to_every_building():
    w=read_table(ROOT/'data/examples/prediction_wide.csv');w['observed_uy_max_cm']=15
    with pytest.raises(ValueError,match='replicate'):prepare_inputs(w,fmt='wide')


def test_training_has_true_final_counts(training):
    assert len(training)==2325
    assert training.AnalizNo.nunique()==1099
    assert training.H_B.min()==1 and training.H_B.max()==2


@pytest.mark.parametrize('mode',['raw','log1p','asinh50','norm_log1p'])
def test_transform_inverse_roundtrip(training,mode):
    sample=training.iloc[:30]
    z=transform_targets(sample,mode)
    np.testing.assert_allclose(inverse_targets(sample,z,mode),sample[['uy_min_cm','uy_fark_cm']],rtol=1e-12,atol=1e-12)


def test_formula_is_consistent_and_nonnegative(training):
    d=training.iloc[:2]
    pred=reconstruct(d,np.array([[20.,30.],[-10.,-3.]]))
    np.testing.assert_allclose(pred.uy_max_cm_pred,pred.uy_min_cm_pred+pred.uy_fark_cm_pred)
    assert pred.iloc[1].uy_max_cm_pred==0
    np.testing.assert_allclose(pred.T_deg_pred,np.degrees(np.arctan(pred.uy_fark_cm_pred/(100*d.B_m))))


def test_training_negative_or_reversed_outputs_fail(training):
    x=training.iloc[:10].copy();x.loc[0,'uy_max_cm']=-3
    with pytest.raises(ValueError,match='convention'):training_table(x)


def test_target_columns_do_not_affect_predictions(cases):
    b=load_bundle(ROOT/'models/final.joblib');d,_=prepare_inputs(cases)
    p=predict_bundle(b,d)
    changed=d.copy();changed['observed_uy_min_cm']=9999;changed['observed_T_deg']=9999
    q=predict_bundle(b,changed)
    for c in ['uy_min_cm_pred','uy_fark_cm_pred','uy_max_cm_pred','T_deg_pred','high_response_probability','T_deg_lo90','T_deg_hi90']:
        np.testing.assert_allclose(p[c],q[c],rtol=0,atol=1e-12)


def test_frozen_model_parameters_match_config(config):
    b=load_bundle(ROOT/'models/final.joblib');m=b['point_model'].named_steps['model']
    assert m.n_estimators==config['n_estimators']==60
    assert m.random_state==config['random_state']==1777


def test_classifier_label_definition_is_not_q90(training):
    b=load_bundle(ROOT/'models/final.joblib')
    actual=b['high_response_classifier'].predict(training[CORE])
    np.testing.assert_array_equal(actual,(training.T_deg>5).astype(int))
    assert sum(actual)==78


def test_uncertain_zeros_are_not_training_or_error_targets(cases):
    b=load_bundle(ROOT/'models/final.joblib');d,_=prepare_inputs(cases);pred=predict_bundle(b,d);e=observed_reference(pred)
    assert len(e)==14
    assert e.uy_max_cm.notna().sum()==12
    assert e.loc[e.BuildingID.isin(['C23','C2']),'uy_max_cm'].isna().all()
    # Single minimum zeros with a numeric maximum were not blanket-deleted.
    assert e.loc[e.BuildingID.eq('KA3'),'uy_min_cm'].iloc[0]==0


def test_archived_external_point_predictions_reproduced(cases):
    b=load_bundle(ROOT/'models/final.joblib');d,_=prepare_inputs(cases);p=predict_bundle(b,d)
    old=read_table(ROOT/'reference/archived_external_predictions.csv')
    mapping={'uy_min_cm_pred':'pred_uy_min_cm','uy_fark_cm_pred':'pred_delta_uy_cm','uy_max_cm_pred':'pred_uy_max_cm','T_deg_pred':'pred_T_deg'}
    for a,c in mapping.items():np.testing.assert_allclose(p[a],old[c],atol=5.1e-5,rtol=0)


def test_f16_reads_stored_upper_response_quantile(cases):
    b=load_bundle(ROOT/'models/final.joblib');d,_=prepare_inputs(cases);p=predict_bundle(b,d)
    f=p[p.BuildingID.eq('F16')].iloc[0]
    assert f.high_response_flag==1
    assert f.interval_source=='upper_response_residuals'
    np.testing.assert_allclose(f.T_deg_hi90-f.T_deg_pred,b['residual_quantiles']['T_deg']['upper_response'])


def test_external_metrics_do_not_cherry_pick(cases):
    b=load_bundle(ROOT/'models/final.joblib');d,_=prepare_inputs(cases);e=observed_reference(predict_bundle(b,d))
    cov=coverage_metrics(e).set_index('target')
    assert cov.loc['uy_min_cm','inside']==3 and cov.loc['uy_min_cm','n']==12
    assert cov.loc['uy_max_cm','inside']==5
    assert cov.loc['T_deg','inside']==6


def test_marginal_and_joint_scope_notes(cases,training):
    d,_=prepare_inputs(cases);notes=scope_warnings(d,range_metadata(training))
    c=notes.loc[d.BuildingID.eq('C26')].iloc[0]
    assert 'B_m' in c.outside_training_features
    assert 'H_B' in c.outside_training_features
    assert 'Q/H' in c.scope_notes
    assert 'heterogeneous' in c.scope_notes


def test_smoke_preprocess_cv_train_predict(tmp_path,config,training,cases):
    # Balanced small subset of whole analysis groups; not performance evidence.
    ids=training.AnalizNo.drop_duplicates().iloc[::12].tolist()
    small=training[training.AnalizNo.isin(ids)].copy()
    path=tmp_path/'input.csv';write_table(small,path)
    preprocess(path,tmp_path/'pre')
    cfg=deepcopy(config);cfg.update(n_estimators=5,classifier_n_estimators=5,n_splits=3,n_jobs=1)
    validate(tmp_path/'pre/training_long.csv',tmp_path/'val',cfg)
    train(tmp_path/'pre/training_long.csv',tmp_path/'val',tmp_path/'model.joblib',cfg)
    inp=tmp_path/'cases.csv';write_table(cases,inp)
    predict(inp,tmp_path/'model.joblib',tmp_path/'pred')
    evaluate(tmp_path/'pred/predictions.csv',tmp_path/'evaluation',cfg)
    assert read_table(tmp_path/'evaluation/all_case_results.csv').shape[0]==14
    assert read_table(tmp_path/'val/fold_audit.csv').shared_groups.eq(0).all()


def test_xlsx_template_matches_development_example():
    x = read_table(ROOT / 'data/examples/Input_Template.xlsx', sheet='Inputs')
    d, _ = prepare_inputs(x)
    c, _ = prepare_inputs(read_table(ROOT / 'data/examples/prediction_long.csv'))
    assert len(d) == 6
    np.testing.assert_allclose(d[['B_m','H_m','H_B','Q_kPa','w_m','Df_m']], c[['B_m','H_m','H_B','Q_kPa','w_m','Df_m']])
    assert d.groupby('CaseID').size().tolist() == [1, 2, 3]


def test_csv_roundtrip_preserves_training_signature(tmp_path,training):
    p=tmp_path/'training.csv'
    write_table(training,p)
    reread=training_table(read_table(p))[0]
    assert frame_signature(training)==frame_signature(reread)


def test_formula_export_is_complete(training):
    from settlementml.hinge import predict_formula
    formula_path=ROOT/'reference/release_coefficients/formula.json'
    if not formula_path.exists():
        pytest.skip('Release coefficient artifacts not installed yet')
    formula=read_json(formula_path)
    d=training.iloc[:40].copy()
    raw=predict_formula(formula,d)
    std=[]
    for term in formula['terms']:
        x=d[term['input']]
        if term['kind']=='category':v=x.astype(str).eq(term['category']).astype(float).to_numpy()
        elif term['kind']=='linear':v=x.to_numpy(float)
        elif term['kind']=='right_hinge':v=np.maximum(0,x.to_numpy(float)-term['knot'])
        else:v=np.maximum(0,term['knot']-x.to_numpy(float))
        std.append((v-term['mean'])/term['scale'])
    X=np.column_stack(std)
    direct=np.column_stack([v['intercept_standardized']+X@np.array(v['coefficients_standardized']) for v in formula['targets'].values()])
    np.testing.assert_allclose(raw,reconstruct(d,direct),atol=1e-10,rtol=0)


def test_configuration_change_cannot_reuse_calibration(tmp_path,training,config):
    d=training.iloc[:20].copy();p=tmp_path/'data.csv';write_table(d,p)
    val=tmp_path/'val';val.mkdir()
    from settlementml.io import write_json
    write_json({'canonical_signature':frame_signature(d),'config':config},val/'validation_manifest.json')
    changed=deepcopy(config);changed['classifier_probability_threshold']=.4
    with pytest.raises(ValueError,match='classifier_probability_threshold'):
        train(p,val,tmp_path/'model.joblib',changed)
