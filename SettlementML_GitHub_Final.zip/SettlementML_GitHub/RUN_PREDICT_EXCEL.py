"""Edit the four settings below, then use the IDE Run button."""
from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parent
INPUT_FILE = ROOT / "data/examples/Input_Template.xlsx"
SHEET = "Inputs"
MODEL_FILE = ROOT / "models/final.joblib"  # or ROOT / "outputs/models/final.joblib"
OUTPUT_FOLDER = ROOT / "outputs/excel_prediction"

if __name__ == "__main__":
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    from settlementml.__main__ import main
    main(["predict", "--input", str(INPUT_FILE), "--sheet", SHEET,
          "--model", str(MODEL_FILE), "--out", str(OUTPUT_FOLDER)])
    main(["figures", "--run", str(OUTPUT_FOLDER)])
