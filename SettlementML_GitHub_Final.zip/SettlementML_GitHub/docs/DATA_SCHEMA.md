# Veri ve kolon sözlüğü

## 1. Girdi birimi ve bina konumları

Bir long-format satırı tek bir binanın konumuna ait girdilerdir. İki bina ayrık/bitişik: **Sol Bina + Sag Bina**. Üç bina ayrık/bitişik: **Sol Bina + Orta Bina + Sag Bina**. Tekil bina etiketi `Sol Bina`dır; burada fiziksel olarak başka bir binanın solunda bulunduğu anlamına gelmez.

`CaseID` ve `BuildingID` tahmin verisindeki kimliklerdir. `AnalizNo` eğitim/doğrulamadaki grup kimliğidir. Hiçbiri öğrenilen feature değildir. Birbirinden bağımsız tekil binalar aynı saha CaseID'sinde bulunabilir; çizim sırasında ayrı bina olarak ele alınır.

| Kaynak/girdi adı | Birim/tür | İşlem ve açıklama |
|---|---|---|
| Senaryo | Kategori | Beş izinli sınıf; sayfa sonundaki sözlük |
| ProfilNo | Kategori | P1/P2; zemin profilinin proje içi kodu, yeni profile otomatik dönüşüm yok |
| CAV_cm_s | Kaynaktaki CAV ölçeği | Adlandırma ve değerler arşivden korunur; fiziksel birim dönüşümü otomatik yapılmaz |
| EtkinSure_D5_D95_s | s | Etkin süre; pozitif olmalıdır |
| AriasIntensity_Ia | Kaynakla aynı birim | Mevcut dosyalarda açık birim metadata'sı yoktur; yayımdan önce veri sahibi doğrulamalıdır |
| B_m | m | Temel genişliği, pozitif |
| H_m | m | Bina yüksekliği, pozitif |
| H_B | Boyutsuz | H/B olarak yeniden hesaplanır; verilen oran 5e-4 tolerans dışında farklıysa hata |
| Q_kPa | kPa | Temel basıncı/yük girdisi; kat sayısı veya toplam kuvvet değildir |
| w_m | m veya model kodu | Ayrık sistemde pozitif mesafe; tekil/bitişik kategoride 0 kodu |
| Df_m | m | 1: Bodrumsuz, 3: Bodrumlu; başka değer sessizce sınıflandırılmaz |
| BinaKonumu | Kategori | Sol Bina, Orta Bina, Sag Bina; `Sağ Bina` yazımı normalize edilir |

Kategori karşılıkları:

| Senaryo | Yerlesim | BinaSayisi |
|---|---|---:|
| Ayrık (Tekil) Bina | Tekil | 1 |
| İki Bina Ayrık | Ayrık | 2 |
| İki Bina Bitişik | Bitişik | 2 |
| Üç Bina Ayrık | Ayrık | 3 |
| Üç Bina Bitişik | Bitişik | 3 |

`Yerlesim` ve `BinaSayisi` senaryodan; `BodrumDurumu` Df'den türetilir. Bu türetimler önceden tanımlı kategori kurallarıdır, hedeflerden öğrenilmez. `BinaKonumu`, eski wide Excel'de hangi çıktı bloğunun ilgili binaya ait olduğunu işaretleyen konumdan gelir; çıktı değerinin kendisi feature'a kopyalanmaz.

## 2. Final feature listesi

Kategorik: `Senaryo, Yerlesim, ProfilNo, BodrumDurumu, BinaKonumu`.

Sayısal: `BinaSayisi, CAV_cm_s, EtkinSure_D5_D95_s, AriasIntensity_Ia, B_m, H_m, H_B, Q_kPa, w_m, Df_m`.

Final ExtraTrees'te kategoriler fold içinde one-hot kodlanır, sayısal core girdiler ham ölçekte kullanılır. Senaryo/yerleşim/sayı ve Df/bodrum gibi değişkenlerin birbirine bağlı olduğu bilinmektedir; önem katsayıları bağımsız nedensel etkiler gibi okunamaz.

`selected` ablation: core + `w_over_B, H_times_Q, KonumIndex, KenarBina`.

`full_engineered` ablation: core + yukarıdakiler + `w_over_H, SlenderLoad, Intensity_CAV_Ia, Intensity_CAV_Duration, Arias_per_Duration`.

Final core feature listesinde bu ek oran/çarpımlar yoktur. `H_B` kaynakta bulunan temel orandır ve core'da kalır.

## 3. Hedefler ve gözlem statüsü

Eğitim için `uy_min_cm` ve `uy_max_cm` gereklidir. Pozitif oturma büyüklüğü kullanılır; min/max sıralaması kontrol edilir. `uy_fark_cm` farktan hesaplanır. `T_deg` verilmişse geometrik formülle karşılaştırılır; fark 0.02°'yi aşarsa sessizce düzeltmek yerine durulur. Bu tolerans doğrulama amaçlı sayısal yuvarlama toleransıdır, kabul edilebilir tahmin hatası değildir.

Tahmin dosyasında gözlem değerleri zorunlu değildir. Değerlendirme için:

```text
observed_uy_min_cm
observed_uy_max_cm
observed_T_deg
observed_status
```

`numeric` sayısal karşılaştırmayı; `non-observable`, `unknown`, `qualitative` ve `not_observed` nitel/eksik referansı belirtir. İki belirsiz 0/0/0 kayıt dış vaka örneğinde açıkça `non-observable`dır. Gözlem bulunmadığında yaklaşık bir algılama sınırı uydurulmaz; bu dosya için 0–10 cm aralığı kabul edilmez. Diğer numeric min=0 değerleri yalnızca sıfır olduğu için silinmez. Gözlemlerin ölçüm doğruluğu kullanıcı/veri sahibinin sorumluluğudur.

Eğitim ve dış vaka gözlemlerini karıştırmayın. `external_cases.csv` varsayılan eğitim dosyası değildir.

## 4. Excel ve CSV

Önerilen Excel şablonu `data/examples/Input_Template.xlsx`, sayfa **Inputs**, başlık satırı **1**. Doldurulmuş 6 satır geliştirme verisinden 1 tekil, 1 ikili ve 1 üçlü kullanım örneğidir. Gerçek dış doğrulama örneği değildir. `H_B` formülü ve açılır listeler kullanılabilir; kod boş H/B'yi de hesaplar.

Okuyucu CSV/TSV ve **.xlsx** destekler. XLSX formüllerini çalıştırmaz; kaydedilmiş önbellek değerlerini okur. Boş zorunlu hücreyi medyanla doldurmaz. XLS/XLSM veya biçimi bilinmeyen Excel otomatik tahmin edilmez.

Wide girdi, bir homojen senaryoyu tüm konumlara açar. Aynı vakadaki binalar farklı B/H/Q/Df değerlerine sahipse long format gerekir. Wide satırda bir observed değerin bütün binalara kopyalanması reddedilir.

## 5. Eski orijinal analiz Excel'i

İsteğe bağlı `preprocess --format original --start-row 4` okuyucusu mevcut arşiv yapısına özeldir:

| Excel sütunları | Anlam |
|---|---|
| A | AnalizNo |
| B | Senaryo açıklaması |
| C | Profil |
| D/E/F | CAV / etkin süre / Arias |
| G/H/I/J/K/L | B / H / H/B / Q / w / Df |
| M/N/O | Sol bina uy_min / uy_max / T |
| P/Q/R | Orta bina uy_min / uy_max / T |
| S/T/U | Sağ bina uy_min / uy_max / T |

Kodu farklı bir düzene sahip saha Excel'ine doğrudan uygulamayın. İlk sütun BuildingID ise bu format değildir. Yeni şablonun long-format okuyucusunu kullanın.

## 6. QC ve veri geçmişi

`data/training_qc.csv` zaten onaylanmış 2325 kayıttır. Varsayılan işlem yeniden bir üst hedef eşiği uygulamaz. Eski orijinal geniş tabloda nümerik artefakt olarak değerlendirilen kayıtları yeniden elemek için tarihsel politika ayrı dosyada açık biçimde tutulur: `configs/legacy_expert_qc.json`. Bu isteğe bağlı politika `uy_max>500 cm OR T>10°` bina-gözlemlerini çıkarır; analiz ailesini topluca silmez. Filtre öncesi/sonrası ve çıkarılan satırlar kaydedilir. Bu tarihsel veri hazırlama kuralı, evrensel fiziksel güvenlik sınırı değildir.

## 7. Kapsam ve yeni geometri

Eğitim tasarımında B={9,12} m, H={9,12,15,18,24} m, H/B∈[1,2], Q∈[60,160] kPa; ayrık sistemlerde w={3,4,4.5,6,9,12} m; Df={1,3} m. Üçlüde yalnızca Df=1 vardır. Tam değer listeleri `models/final.metadata.json` içindedir.

`outside_training_features` marjinal aralığı aşan girdileri gösterir. `unseen_training_levels` aralık içinde olsa bile görülmemiş sayısal düzeyleri; `scope_notes` örneklenmemiş B/H/Q/Df kombinasyonlarını, eğitimdeki Q/H bağıntısından sapmayı ve heterojen komşu bina durumunu belirtir. Bu bayrakların boş olması tam fiziksel geçerlilik veya güvenlik garantisi değildir.

Mevcut model satırda yalnızca hedef binanın B/H/Q/Df değerlerini ve genel senaryo/konumunu alır. Diğer binaların ayrı özelliklerini ek girdiler olarak içermez. Bu nedenle farklı boyutlu komşu sistemlerdeki tam etkileşim açıklanmış sayılmaz.
