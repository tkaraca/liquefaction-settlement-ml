# Reproducibility record

## What the package actually reproduces

There are three separate checks, which should not be conflated:

1. **Frozen predictions:** the shipped archived fitted estimator is used unchanged. Its point predictions on all 14 external buildings agree with the previously exported, four-decimal CSV to the expected rounding tolerance (<5.1e-5).
2. **Full-data refitting:** 60 trees, seed 1777, core/raw/unweighted refitting on the supplied development data reproduced the frozen external point predictions to about 1.4e-14 cm in this environment. This is stronger than simply loading the same model twice. Calibration quantiles are still different if regenerated from new OOF folds.
3. **Historical versus new OOF results:** historical OOF metrics are exactly recomputable from the archived prediction table. The old artifacts did not completely record fold-specific fitting seeds, so the new deterministic OOF run is explicitly a **new release run**, not a claimed exact recreation of those old fitted fold models.

`reference/checks/model_reproduction_check.json`, `archived_metrics_check.json` and `end_to_end_check.json` contain the checks. The reference data/model files have SHA256 integrity records.

## Environment and deterministic choices

Local execution environment: Python 3.13.5, Linux; NumPy 2.3.5, pandas 2.2.3, SciPy 1.17.0, scikit-learn 1.8.0, joblib 1.5.3, matplotlib 3.10.8. Optional family tests used XGBoost 3.1.3, LightGBM 4.6.0 and CatBoost 1.2.8. See `reference/checks/execution_environment.json` for the complete recorded environment.

The main workflow uses GroupKFold(5), no shuffle, ordered canonical rows, and point-model fold seeds 1778–1782. Final all-data point seed is 1777. Auxiliary classifier seeds are 1889–1893 in folds and 1888 for all-data refitting. Full configuration values live in `configs/final.json`; each experiment writes the configuration it actually used. `--jobs` controls parallelism. Tiny floating-point differences from summation order are not treated as scientific changes.

The canonical signature represents ordered model-relevant values, with numerical text rounded to 12 significant digits; file byte SHA256 is separate. The canonical development signature is:

```text
9a70b8f9b3ad9c3ae230dbb4de8e7a8def536c939d9a992e33c92e6015e1f08a
```

The standard release table has 2325 rows / 1099 analysis groups. The optional original-wide XLSX import plus the explicitly configured historical QC policy reproduced this same canonical signature. The unfiltered original workbook is not silently relabeled as the final table.

## Historical and newly executed point metrics

| Target | Archived OOF MAE | New release OOF MAE | Unit |
|---|---:|---:|---|
| uy_min | 5.357562 | 5.380964 | cm |
| delta uy | 6.510179 | 6.560719 | cm |
| uy_max | 6.610973 | 6.534929 | cm |
| T | 0.353111 | 0.356295 | degrees |

These are two distinct recorded runs; manuscript tables should identify the selected result set consistently. This repository does not combine whichever cell is smaller from the two tables. All target metrics are building-record-weighted, not equal-weighted per analysis.

## Band checks

The archived residual quantiles are stored with the frozen model. Coverage computed on the same residual data used to choose a quantile is not independent evidence for future coverage. The release records it as `calibration_diagnostics_NOT_independent.csv`.

The optional **nested interval check** trains/calibrates only on the groups in each outer-training fold, using three inner GroupKFold folds. The outer validation labels are not used to construct that fold's interval. The new outer-held-out coverage in this run was:

| Target | Covered / total | Empirical coverage |
|---|---:|---:|
| uy_min | 2164 / 2325 | 93.08% |
| delta uy | 2177 / 2325 | 93.63% |
| uy_max | 2177 / 2325 | 93.63% |
| T | 2188 / 2325 | 94.11% |

These are observed development-distribution results of the extra check. They are not the external case-study coverage and do not establish an arbitrary-distribution or finite-sample conformal guarantee. The point model was not improved by these wider intervals.

## Ablation scope

Executed suites: 12 feature representations, 8 target/weighting variants, 8 ANN variants, 10 other-family variants. Suites overlap; these counts must not be added as 38 distinct independent model families. Feature/core references occur in more than one suite.

The comparisons use identical release group splits and point-model fold seeds. They use documented fixed settings rather than exhaustive equal-budget hyperparameter searches. ANN uses max_iter=250, early_stopping=False; iteration-budget warnings are recorded. Early stopping was disabled to avoid an internal row-wise split across correlated building records. New ANN scores therefore need not equal old ANN tables.

Feature-comparison bootstrap intervals resample AnalizNo clusters and report paired OOF error differences. They are exploratory intervals on one OOF experiment, not multiple-testing-corrected model-selection inference. Reusing OOF data for feature/model choice can create optimism; this is not removed solely by group separation.

Some current transformation variants improve certain metrics over the frozen default. For example, the unweighted asinh50 core variant has a slightly lower global uy_max MAE in the current target suite. This observation is retained in the results. It does **not** automatically replace the historical raw/core default, and this release makes no claim that the frozen default is optimal across every metric or model setting.

ANN execution was interrupted near the final configuration and resumed from matching configuration/data hashes. The run-status files distinguish cache reuse from fitting; a cached invocation's elapsed time is not full ANN training time.

## Equation baseline

The additive quantile-knot linear-spline model uses q25/q50/q75 knots fitted inside each training fold, standardized numerical bases, unscaled one-hot categorical bases and ridge alpha=10. It is fitted to observed min/delta targets, not to ExtraTrees predictions. A linear ridge baseline is also evaluated. These are not adaptive MARS implementations.

Full-development coefficients are refitted after OOF evaluation and exported with basis means/scales. The raw-basis intercept is corrected by subtracting the centering contributions. The executable JSON formula agrees with the fitted spline pipeline to 5.68e-14 on all 2325 development rows. That is an implementation-equivalence check, not an out-of-sample performance score.

## External evaluation

The supplied frozen model is not updated with external records. Full data remain visible; uncertain C23/C2 records are natively flagged qualitative and excluded only from numeric comparison. Several plots share a CaseID; this does not make each building statistically independent. Wider tolerance k/n summaries and diagnostic coverage are separate outputs. No poor-prediction exclusion or retrospective interval enlargement is applied.

## Checks performed and not performed

35 automated tests passed locally. The full main CLI pipeline, XLSX Run-button path from a different working directory, original-layout import, all four ablation suites and coefficient export were executed. Source modules were compile-checked. Representative generated figures and the Excel template were visually inspected.

GitHub Actions, Windows/macOS execution and a fresh network installation in each OS environment have **not** been run as part of local preparation. The CI file is a runnable definition, not a passed remote badge. Scientific validation against new independently measured case records remains a separate research task.
