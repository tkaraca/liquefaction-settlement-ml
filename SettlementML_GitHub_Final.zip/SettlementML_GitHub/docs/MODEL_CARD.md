# Model card: SettlementML 1.0.0

## Intended use

Research-level estimation of minimum settlement and differential settlement in the numerical scenario space represented by the development data. Maximum settlement and rotation are reconstructed consistently. The model supports auditable external case demonstrations; it is not an engineering code, damage classifier, certified safety limit or replacement for site-specific numerical/field assessment.

## Frozen point model

- Estimator: scikit-learn ExtraTreesRegressor, multi-output.
- Trees: **60**; seed **1777**; default split/leaf settings documented in `configs/final.json` and model metadata.
- Representation: core categorical variables one-hot encoded, core numerical variables unscaled.
- Targets: raw `uy_min_cm`, `uy_fark_cm`; no log compression, no sample weighting.
- Deployment reconstruction: nonnegative component estimates, their sum for uy_max, arctangent relationship for rotation. No upper cap is imposed to improve errors.
- `models/final.joblib` preserves the archived fitted point and auxiliary classifier estimators. The containing bundle format and metadata were migrated for clarity.

The full-data refit in this release reproduced the frozen point predictions on the 14 external records to floating-point accuracy (maximum discrepancy about 1.4e-14 cm). New CV calibration can produce different band widths; this does not change the frozen point estimates.

## Two distinct response descriptors

**High-response classifier:** the stored auxiliary ExtraTreesClassifier was fitted to `T_deg > 5°`. This gives 78 positives in the development data. The release calls its outputs `high_response_probability` and `high_response_flag`; the threshold defaults to 0.30. The score has not been shown to be a calibrated failure probability.

**Upper-response descriptive subset:** union of `T >= q90(T)` and `uy_max >= q90(uy_max)`. Archived descriptive cut points are about 2.609862° and 135.96 cm, yielding 300/2325 records (12.9%, not exactly 10%). These are distribution descriptors, not data deletion criteria or physical damage thresholds. This subset also defines a residual pool in the archived diagnostic-band scheme.

These definitions are not interchangeable. The archived classifier did not learn the q90-union label. They are deliberately separated in names and metadata instead of relabeling the old classifier as something it was not.

## Diagnostic bands

For each target, a historical OOF absolute-error quantile q is used to report `[max(0, prediction-q), prediction+q]`. `global` mode uses all-data residual quantiles. `gated_diagnostic` uses the archived classifier to choose global versus upper-response residual quantiles. It never switches the point regressor.

The archived wrapper sometimes looked for `upper`/`nonupper` keys while the saved dictionary contained `upper_response`. This release reads the actual stored key. The F16 case therefore receives the wider upper-response residual band consistently.

The new delta band is computed from archived delta OOF residuals; the other frozen quantiles are preserved. Bands are target-wise diagnostics. Their endpoints are not constrained to sum, so a uy_max interval is **not** formed by adding independently calibrated min and delta endpoints. Point estimates, unlike independently calibrated intervals, satisfy the kinematic identities.

Nominal 90% does not imply guaranteed future coverage, simultaneous coverage across four targets, a safety interval, or an uncertainty distribution valid under arbitrary input shift. Counting coverage on the same OOF residuals used to select q mostly checks calibration, not independent interval validity. An optional nested group calibration check is implemented to keep the outer test groups out of calibration. It does not confer a general conformal coverage guarantee.

## Evaluation evidence and limitations

Historical OOF point metrics are provided for traceability, with a separate deterministic rerun under fully recorded seeds. The same fold results were used during development/model comparison; no independent nested model-selection claim is made. GroupKFold addresses sharing of AnalizNo across folds, not every dependency in the simulation design.

The entire external file is retained. It contains 14 buildings; 12 have interpretable numeric reference values. The other two have lack-of-observable-evidence zeros and are retained qualitatively. Under the frozen model, maximum-settlement MAE is approximately 32.29 cm, versus 6.61 cm in historical development OOF results. External residual-band coverage is 3/12 for uy_min, 5/12 for uy_max and 6/12 for T. The new delta-band diagnostic covers 5/12. This undercoverage is reported, not replaced by a claim of 90% external coverage.

Tolerance rates at ±25/50/75 cm and ±1/2/3° are separate exploratory descriptive summaries. Looser tolerances can raise their percentages without improving the underlying model. They are not formal acceptance limits or calibrated prediction intervals. Errors use all available numeric references, not only close-match examples. Case-level grouping means 12 building records are not 12 fully independent experiments.

B exceeds development support in many external records; H/B is also below the development range in several. However, input shift is a possible contributor, not a proven sole cause of all errors: some large mismatches occur within marginal geometry bounds. Field-reference uncertainty, unsupported joint inputs, contact/spacing representations and heterogeneous neighboring buildings also limit interpretation.

## Feature interpretation

MDI importance and coefficient-baseline values are model-specific associations. Correlated/redundant descriptors (scenario, layout, building count; Df/basement; H/Q) can distribute apparent importance among representations. They do not establish causal effects of soil profile, geometry or building position.

## Data and sharing

See `data/DATA_PROVENANCE.json`. This distribution contains development records, fitted models and external examples supplied in the project. The research team must verify redistribution rights before a public GitHub release. A license, publication DOI, authorship list and scientific claim of regulatory approval have not been assigned by this package.
