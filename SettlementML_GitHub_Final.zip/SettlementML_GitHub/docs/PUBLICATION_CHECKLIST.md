# Public GitHub release checklist

The repository works locally. Before public publication, the research team should complete these administrative and scientific checks.

- Confirm permission to distribute `data/training_qc.csv`, external case records, archived result tables and fitted models. Public repository permission is not inferred from having used data in a private analysis.
- Decide a **code license** and a separate **data/model license**, where appropriate. This package intentionally does not grant rights on behalf of the authors or data owners.
- Add the real repository URL, maintainer/contact information and an actual citation after author/title/DOI confirmation. Do not use a made-up DOI or year. See `CITATION_TEMPLATE.md`.
- Verify physical input units, especially CAV and Arias intensity metadata, and the intended left/right reference direction in the simulations. Column labels are preserved from project inputs.
- State QC criteria in reproducibility documentation. Invalid numerical outputs are not valid physical measurements, but the processing history must still be traceable.
- Use the same configuration/model version in Methods, Results, scripts and archived artifacts. Resolve the legacy 500-tree wrapper versus actual 60-tree model before manuscript submission.
- Distinguish development OOF model comparison from independent external evaluation and nested interval calibration. State that model-selection uncertainty is not fully assessed by the non-nested development comparisons.
- Do not label the T>5 classifier as a q90-union predictor or as a structural-failure probability.
- State external observation limitations and retain full-case data. Figures of especially close examples are illustrative selections, not the complete external performance estimate.
- Run `python -m pytest` and `python scripts/verify_release.py` after extraction. GitHub Actions is provided but must run in the real repository before describing it as a passed CI test.
- Upload directory contents so `README.md`, `settlementml/`, `configs/` and `data/` are at the repository root. Keep `.venv/`, `outputs/`, caches and logs out of the repository unless intentionally released as a versioned reference.
- If a file changes deliberately after publication, regenerate the SHA256 manifest and record the change rather than calling the old reference hash current.

No GitHub account action, repository creation or public upload was performed when preparing this package.
