"""CLI: python -m settlementml --help"""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
import json
from threadpoolctl import threadpool_limits
from .io import read_json,read_table,write_table,write_json
from .models import environment
from .workflows import preprocess,validate,train,predict,evaluate

ROOT=Path(__file__).resolve().parents[1]


def main(argv=None):
    ap=argparse.ArgumentParser(description="SettlementML: preprocess, grouped validation, training and complete-case prediction")
    sub=ap.add_subparsers(dest="command",required=True)
    def config(p):
        p.add_argument("--config",default=str(ROOT/"configs/final.json"))
        p.add_argument("--jobs",type=int,default=None)
    p=sub.add_parser("doctor",help="Print Python/library versions and model configuration")
    config(p)
    p=sub.add_parser("preprocess",help="Validate CSV/XLSX training data; optional original wide-layout import")
    p.add_argument("--input",default="data/training_qc.csv");p.add_argument("--out",default="outputs/preprocessed")
    p.add_argument("--format",choices=["long","original"],default="long");p.add_argument("--sheet",default=None);p.add_argument("--start-row",type=int,default=4);p.add_argument("--qc-policy",default=None)
    p=sub.add_parser("validate",help="GroupKFold OOF metrics, audits and diagnostic calibration")
    config(p);p.add_argument("--input",default="outputs/preprocessed/training_long.csv");p.add_argument("--out",default="outputs/validation");p.add_argument("--nested-bands",action="store_true",help="Also validate residual bands using calibration fitted only inside outer training groups")
    p=sub.add_parser("train",help="Train all development records with configuration matched to validation")
    config(p);p.add_argument("--input",default="outputs/preprocessed/training_long.csv");p.add_argument("--validation",default="outputs/validation");p.add_argument("--out",default="outputs/models/final.joblib")
    p=sub.add_parser("predict",help="Apply a fitted model; no observed outputs needed")
    p.add_argument("--input",default="data/examples/prediction_long.csv");p.add_argument("--model",default="models/final.joblib");p.add_argument("--out",default="outputs/predictions");p.add_argument("--format",choices=["long","wide"],default="long");p.add_argument("--sheet",default=None);p.add_argument("--allow-partial-cases",action="store_true");p.add_argument("--interval-mode",choices=["global","gated_diagnostic"],default=None)
    p=sub.add_parser("evaluate",help="Compare numeric external references, retaining uncertain rows qualitatively")
    config(p);p.add_argument("--predictions",default="outputs/predictions/predictions.csv");p.add_argument("--out",default="outputs/external")
    p=sub.add_parser("figures",help="Generate CSV-linked PNG/SVG figures and an HTML gallery")
    p.add_argument("--run",default="outputs/validation")
    p=sub.add_parser("ablation",help="Controlled feature, transformation, ANN and family benchmarks")
    config(p);p.add_argument("--input",default="data/training_qc.csv");p.add_argument("--out",default="outputs/ablation");p.add_argument("--suite",choices=["features","targets","ann","families","all","smoke"],default="features");p.add_argument("--ann-max-iter",type=int,default=None);p.add_argument("--resume",action="store_true")
    p=sub.add_parser("coefficients",help="Fit linear/quantile-knot spline ridge baselines and export equations")
    p.add_argument("--input",default="data/training_qc.csv");p.add_argument("--out",default="outputs/coefficients");p.add_argument("--folds",type=int,default=5)
    p=sub.add_parser("formula-predict",help="Predict using the exported hinge-regression equation JSON")
    p.add_argument("--input",default="data/examples/prediction_long.csv");p.add_argument("--formula",default="outputs/coefficients/formula.json");p.add_argument("--out",default="outputs/formula_predictions.csv")
    p=sub.add_parser("reference-check",help="Recompute archived metrics; never calls this a newly repeated experiment")
    p.add_argument("--out",default="outputs/reference_check")
    p=sub.add_parser("all",help="Preprocess -> validate -> train -> external prediction/evaluation -> figures")
    config(p);p.add_argument("--input",default="data/training_qc.csv");p.add_argument("--cases",default="data/examples/external_cases.csv");p.add_argument("--out",default="outputs/full_run");p.add_argument("--nested-bands",action="store_true")
    args=ap.parse_args(argv)
    cfg=read_json(args.config) if hasattr(args,"config") else None
    if cfg is not None and args.jobs is not None:cfg["n_jobs"]=args.jobs
    def sheet_value():return 0 if args.sheet is None else (int(args.sheet) if args.sheet.isdigit() else args.sheet)
    try:
        with threadpool_limits(limits=1):
            if args.command=="doctor":
                print(json.dumps({"environment":environment(),"config":cfg,"project_root":str(ROOT)},ensure_ascii=False,indent=2))
            elif args.command=="preprocess":preprocess(args.input,args.out,args.format,sheet_value(),args.start_row,args.qc_policy)
            elif args.command=="validate":validate(args.input,args.out,cfg,args.nested_bands)
            elif args.command=="train":train(args.input,args.validation,args.out,cfg)
            elif args.command=="predict":predict(args.input,args.model,args.out,args.format,sheet_value(),not args.allow_partial_cases,args.interval_mode)
            elif args.command=="evaluate":evaluate(args.predictions,args.out,cfg)
            elif args.command=="figures":
                from .plots import render_figures
                render_figures(args.run)
            elif args.command=="ablation":
                from .ablation import run_ablation
                if args.ann_max_iter is not None:cfg["ann_max_iter"]=args.ann_max_iter
                run_ablation(args.input,args.out,cfg,args.suite,args.resume)
            elif args.command=="coefficients":
                from .hinge import fit_hinge_report
                fit_hinge_report(args.input,args.out,args.folds)
            elif args.command=="formula-predict":
                from .hinge import predict_formula
                from .data import prepare_inputs
                import pandas as pd
                d,_=prepare_inputs(read_table(args.input));pr=predict_formula(read_json(args.formula),d);write_table(pd.concat([d,pr],axis=1),args.out)
            elif args.command=="reference-check":
                from .metrics import regression_metrics,tolerance_metrics,coverage_metrics,observed_reference
                import numpy as np
                o=Path(args.out);o.mkdir(parents=True,exist_ok=True)
                historical=read_table(ROOT/"reference/archived_core_oof.csv")
                computed=regression_metrics(historical,source="archived_OOF_recomputed")
                write_table(computed,o/"archived_metrics_recomputed.csv")
                ref=read_table(ROOT/"reference/archived_report_metrics.csv")
                delta={}
                for _,r in ref.iterrows():
                    met=computed[computed.target.eq(r.Target)].iloc[0]
                    delta[r.Target]=float(abs(met.MAE-r.MAE))
                write_json({"maximum_MAE_difference":max(delta.values()),"differences":delta,"note":"Metric recomputation from archived predictions. Not evidence that historical OOF fitting seeds were recovered."},o/"reference_check.json")
                print(json.dumps(delta,indent=2))
            elif args.command=="all":
                from .plots import render_figures
                o=Path(args.out);prep=o/"preprocessed";val=o/"validation";model=o/"models/final.joblib";pred=o/"predictions";ev=o/"external"
                preprocess(args.input,prep)
                validate(prep/"training_long.csv",val,cfg,args.nested_bands)
                train(prep/"training_long.csv",val,model,cfg)
                predict(args.cases,model,pred)
                evaluate(pred/"predictions.csv",ev,cfg)
                render_figures(val);render_figures(ev)
    except (ValueError, FileNotFoundError, RuntimeError) as e:
        ap.exit(2,f"ERROR: {e}\n")


if __name__=="__main__":main()
