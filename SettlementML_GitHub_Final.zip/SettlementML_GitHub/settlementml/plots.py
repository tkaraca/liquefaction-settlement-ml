"""One metric axis per figure; all-case gallery with no outcome-based omission."""
from __future__ import annotations
from pathlib import Path
import html
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .data import TARGETS
from .io import read_table,write_table

LABELS={"uy_min_cm":"Minimum settlement", "uy_fark_cm":"Differential settlement", "uy_max_cm":"Maximum settlement", "T_deg":"Rotation"}


def _save(fig,folder,name):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    fig.tight_layout()
    fig.savefig(folder/f"{name}.png",dpi=180,bbox_inches="tight")
    fig.savefig(folder/f"{name}.svg",bbox_inches="tight")
    plt.close(fig)


def _slug(text):
    return re.sub(r"[^a-zA-Z0-9_-]+","_",str(text)).strip("_")


def parity(d,target,outdir,prefix):
    if target not in d:return
    ok=d[target].notna()&d[target+"_pred"].notna()
    if not ok.any():return
    y=d.loc[ok,target];p=d.loc[ok,target+"_pred"]
    fig,ax=plt.subplots(figsize=(5.4,5.2))
    ax.scatter(y,p,s=11,alpha=.35,edgecolors="none")
    mx=max(float(y.max()),float(p.max()),1)*1.05
    ax.plot([0,mx],[0,mx],"--",label="Equality")
    ax.set(xlim=(0,mx),ylim=(0,mx),xlabel=f"Observed ({'degrees' if target=='T_deg' else 'cm'})",ylabel=f"Predicted ({'degrees' if target=='T_deg' else 'cm'})",title=LABELS[target])
    ax.set_aspect("equal",adjustable="box")
    ax.legend()
    _save(fig,outdir,f"{prefix}_parity_{target}")


def tolerance_plot(table,outdir):
    for t in TARGETS:
        g=table[table.target.eq(t)].sort_values("tolerance")
        if g.empty:continue
        fig,ax=plt.subplots(figsize=(6.5,4.0))
        x=np.arange(len(g));vals=g.rate.to_numpy(float)*100
        ax.bar(x,vals)
        for xi,(_,r) in zip(x,g.iterrows()):
            ax.text(xi,r.rate*100+1.5,f"{int(r.within)}/{int(r.n)}\n{100*r.rate:.1f}%",ha="center",fontsize=9)
        ax.set_xticks(x,[f"±{v:g}" for v in g.tolerance])
        ax.set(ylim=(0,118),xlabel=f"Descriptive absolute-error tolerance ({g.unit.iloc[0]})",ylabel="Within tolerance (%)",title=LABELS[t]+": tolerance sensitivity")
        _save(fig,outdir,f"tolerance_{t}")


def case_figures(d,outdir):
    """Group neighbours into complete cases, but keep independent singles separate."""
    if "CaseID" not in d:return
    for case,caseframe in d.groupby("CaseID",sort=False):
        groups=[]
        for scen,g in caseframe.groupby("Senaryo",sort=False):
            if (g.BinaSayisi==1).all():
                groups.extend([(f"{case} / {bid}",single) for bid,single in g.groupby("BuildingID",sort=False)])
            else:groups.append((f"{case} / {scen}",g))
        for label,g in groups:
            g=g.copy();g["_order"]=g.BinaKonumu.map({"Sol Bina":0,"Orta Bina":1,"Sag Bina":2});g=g.sort_values("_order")
            names=[f"{r.BuildingID}\n{r.BinaKonumu}" for _,r in g.iterrows()]
            x=np.arange(len(g));w=.18
            fig,ax=plt.subplots(figsize=(max(5.5,len(g)*2.3),4.6))
            for idx,(t,kind,offset) in enumerate([("uy_min_cm","obs",-1.5*w),("uy_min_cm","pred",-.5*w),("uy_max_cm","obs",.5*w),("uy_max_cm","pred",1.5*w)]):
                vals=g[t] if kind=="obs" and t in g else (g[t+"_pred"] if kind=="pred" else pd.Series(np.nan,index=g.index))
                bars=ax.bar(x+offset,vals,w,label=f"{'Observed' if kind=='obs' else 'Predicted'} {t.replace('_cm','')}")
                if kind=="pred" and t+"_lo90" in g:
                    low=np.maximum(0,vals.to_numpy()-g[t+"_lo90"].to_numpy());high=np.maximum(0,g[t+"_hi90"].to_numpy()-vals.to_numpy())
                    ax.errorbar(x+offset,vals,yerr=[low,high],fmt="none",capsize=3,linewidth=1)
                for rect,value in zip(bars,vals):
                    if np.isfinite(value):ax.annotate(f"{value:.1f}",(rect.get_x()+rect.get_width()/2,rect.get_height()),xytext=(0,3),textcoords="offset points",ha="center",fontsize=7)
            ax.set_xticks(x,names);ax.set(ylabel="Settlement (cm)",title=label+"\nSettlement and diagnostic intervals")
            ax.legend(ncol=2,fontsize=8,loc="upper left",bbox_to_anchor=(0,1.02))
            ax.margins(y=.30)
            if "reference_status" in g and g.reference_status.eq("qualitative_only").any():
                fig.text(.5,.01,"No observed bars for unquantified observations; no exact zero was assumed.",ha="center",fontsize=8)
                fig.subplots_adjust(bottom=.22)
            name="case_"+_slug(label)
            _save(fig,outdir,name+"_settlement")
            fig,ax=plt.subplots(figsize=(max(5.5,len(g)*2.3),4.4))
            p=g.T_deg_pred.to_numpy()
            if "T_deg" in g:ax.bar(x-.15,g.T_deg,.3,label="Observed T")
            ax.bar(x+.15,p,.3,label="Predicted T")
            if "T_deg_lo90" in g:
                ax.errorbar(x+.15,p,yerr=np.vstack([np.maximum(0,p-g.T_deg_lo90.to_numpy(float)),np.maximum(0,g.T_deg_hi90.to_numpy(float)-p)]),fmt="none",capsize=4,linewidth=1)
            ax.set_xticks(x,names);ax.set(ylabel="Rotation (degrees)",title=label+"\nRotation and diagnostic intervals")
            ax.legend(fontsize=9);ax.margins(y=.22)
            _save(fig,outdir,name+"_rotation")


def render_figures(run_dir):
    root=Path(run_dir);out=root/"figures";out.mkdir(parents=True,exist_ok=True)
    if (root/"oof_predictions.csv").exists():
        d=read_table(root/"oof_predictions.csv")
        for t in TARGETS:parity(d,t,out,"OOF")
        tolerance_plot(read_table(root/"tolerance_rates.csv"),out)
        # Descriptive numerical-response summaries; not causal risk classes.
        summary=d.groupby(["Senaryo","BinaKonumu"])[TARGETS].agg(["count","mean","median","max"])
        summary.columns=[a+"_"+b for a,b in summary.columns]
        write_table(summary.reset_index(),root/"scenario_response_summary.csv")
        for t in ["uy_min_cm","uy_max_cm","T_deg"]:
            g=d.groupby("Senaryo")[t].mean().sort_values()
            fig,ax=plt.subplots(figsize=(7.6,4.0));ax.barh(g.index,g.values)
            ax.set(xlabel=f"Observed mean ({'degrees' if t=='T_deg' else 'cm'})",title=LABELS[t]+" by scenario")
            _save(fig,out,f"scenario_{t}")
    elif (root/"all_case_results.csv").exists():
        d=read_table(root/"all_case_results.csv")
        for t in TARGETS:parity(d,t,out,"external")
        case_figures(d,out)
        tolerance_plot(read_table(root/"external_tolerance_rates.csv"),out)
        cv=read_table(root/"external_coverage.csv")
        fig,ax=plt.subplots(figsize=(6.2,4.0));x=np.arange(len(cv));ax.bar(x,cv.coverage*100)
        for i,r in cv.iterrows():ax.text(i,r.coverage*100+2,f"{int(r.inside)}/{int(r.n)}\n{r.coverage*100:.1f}%",ha="center",fontsize=9)
        ax.axhline(90,linestyle="--",label="Nominal level, not a guarantee")
        ax.set_xticks(x,[LABELS[t].replace(" settlement","") for t in cv.target]);ax.set(ylim=(0,112),ylabel="Observed reference inside band (%)",title="External diagnostic coverage: all numeric references")
        ax.legend(fontsize=8)
        _save(fig,out,"external_coverage_all_numeric_cases")
    elif (root/"predictions.csv").exists():
        case_figures(read_table(root/"predictions.csv"),out)
    elif (root/"ablation_metrics.csv").exists():
        d=read_table(root/"ablation_metrics.csv")
        for t in TARGETS:
            g=d[(d.target==t)&(d.subset=="all")].sort_values("MAE")
            if g.empty:continue
            fig,ax=plt.subplots(figsize=(9,max(4.,len(g)*.33)))
            ax.barh(g.configuration,g.MAE);ax.invert_yaxis();ax.set(xlabel="MAE ("+("degrees" if t=="T_deg" else "cm")+")",title=LABELS[t]+": ablation")
            _save(fig,out,f"ablation_{t}")
    else:
        raise ValueError("Run directory has no supported predictions, OOF, evaluation or ablation table.")
    # No JavaScript, web dependency, or selective display of good cases.
    imgs=sorted(out.glob("*.png"))
    panels="\n".join(f'<section><h2>{html.escape(p.stem)}</h2><img src="figures/{p.name}" alt="{html.escape(p.stem)}"></section>' for p in imgs)
    doc='<!doctype html><html lang="en"><meta charset="utf-8"><title>SettlementML outputs</title><style>body{font:16px system-ui;max-width:1200px;margin:2em auto;padding:1em}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:1.5em}img{max-width:100%}h2{font-size:1em}</style><h1>SettlementML output gallery</h1><p>All available figures are shown. CSV tables in the same folder are the numerical source. Diagnostic intervals and descriptive tolerances are different evaluations.</p><main>'+panels+'</main></html>'
    (root/"report.html").write_text(doc,encoding="utf-8")
    print(f"Saved {len(imgs)} PNG + SVG figures and HTML gallery -> {root}",flush=True)
