"""Transparent metric denominators, interval provenance, and missing references."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, median_absolute_error, mean_squared_error, r2_score
from .data import TARGETS


def regression_metrics(d, source="validation", masks=None):
    masks = masks or {"all": np.ones(len(d),dtype=bool)}
    rows=[]
    for subset, mask in masks.items():
        for t in TARGETS:
            if t not in d or t+"_pred" not in d: continue
            ok = np.asarray(mask,dtype=bool) & np.isfinite(d[t].to_numpy(float)) & np.isfinite(d[t+"_pred"].to_numpy(float))
            y=d.loc[ok,t].to_numpy(float); p=d.loc[ok,t+"_pred"].to_numpy(float)
            if not len(y): continue
            rows.append({"source":source,"subset":subset,"target":t,"n":len(y),"unit":"deg" if t=="T_deg" else "cm","MAE":mean_absolute_error(y,p),"MedAE":median_absolute_error(y,p),"RMSE":np.sqrt(mean_squared_error(y,p)),"R2":r2_score(y,p) if len(y)>1 and np.ptp(y)>0 else np.nan,"Bias":np.mean(p-y),"P90_abs_error":np.quantile(abs(p-y),.9),"Max_abs_error":max(abs(p-y))})
    return pd.DataFrame(rows)


def tolerance_metrics(d,cfg):
    rows=[]
    for t in TARGETS:
        if t not in d or t+"_pred" not in d: continue
        ok=d[t].notna() & d[t+"_pred"].notna()
        errors=abs(d.loc[ok,t]-d.loc[ok,t+"_pred"])
        for tol in cfg["tolerances_deg"] if t=="T_deg" else cfg["tolerances_cm"]:
            k=int((errors<=tol).sum()); n=len(errors)
            rows.append({"target":t,"tolerance":tol,"unit":"deg" if t=="T_deg" else "cm","within":k,"n":n,"rate":k/n if n else np.nan,"interpretation":"descriptive sensitivity threshold, not a certified engineering acceptance limit"})
    if all(t in d for t in ["uy_min_cm","uy_max_cm"]):
        ok=d.uy_min_cm.notna() & d.uy_max_cm.notna()
        for tol in cfg["tolerances_cm"]:
            emin=abs(d.loc[ok,"uy_min_cm"]-d.loc[ok,"uy_min_cm_pred"])
            emax=abs(d.loc[ok,"uy_max_cm"]-d.loc[ok,"uy_max_cm_pred"])
            for label, err in [("mean_min_max_absolute_error",(emin+emax)/2), ("both_min_max_within_tolerance",np.maximum(emin,emax))]:
                n=len(err); k=int((err<=tol).sum())
                rows.append({"target":label,"tolerance":tol,"unit":"cm","within":k,"n":n,"rate":k/n if n else np.nan,"interpretation":"nonnegative summary; not a +/- confidence interval"})
    return pd.DataFrame(rows)


def upper_definition(d,cfg):
    level=cfg.get("upper_response_quantile",.90)
    return {"quantile":level,"T_deg":float(d.T_deg.quantile(level)),"uy_max_cm":float(d.uy_max_cm.quantile(level))}


def upper_mask(d,definition):
    return (d.T_deg>=definition["T_deg"]) | (d.uy_max_cm>=definition["uy_max_cm"])


def residual_quantiles(oof,cfg):
    definition=upper_definition(oof,cfg)
    mask=upper_mask(oof,definition)
    qs={}
    for t in TARGETS:
        e=abs(oof[t]-oof[t+"_pred"]).to_numpy(float)
        qs[t]={"global":float(np.quantile(e,cfg.get("diagnostic_coverage",.9),method=cfg.get("quantile_method","higher"))), "upper_response":float(np.quantile(e[np.asarray(mask)],cfg.get("diagnostic_coverage",.9),method=cfg.get("quantile_method","higher")))}
    return qs,definition


def coverage_metrics(d, scheme="reported_diagnostic"):
    rows=[]
    for t in TARGETS:
        if not all(c in d for c in [t,t+"_lo90",t+"_hi90"]): continue
        ok=d[t].notna() & d[t+"_lo90"].notna() & d[t+"_hi90"].notna()
        s=d.loc[ok]; inside=(s[t]>=s[t+"_lo90"]) & (s[t]<=s[t+"_hi90"])
        n=len(s); k=int(inside.sum())
        rows.append({"scheme":scheme,"target":t,"inside":k,"n":n,"coverage":k/n if n else np.nan,"mean_width":float((s[t+"_hi90"]-s[t+"_lo90"]).mean()) if n else np.nan,"nominal_level":.9})
    return pd.DataFrame(rows)


def observed_reference(predictions):
    """Keep predictions for every row; uncertain 0/0/0 entries are not zeros."""
    d=predictions.copy()
    status=d.get("observed_status",pd.Series("numeric",index=d.index)).fillna("unknown").astype(str)
    nonnumeric=status.str.lower().str.contains("non-observable|unknown|qualitative|nonobservable|not_observed",regex=True)
    for target in ["uy_min_cm","uy_max_cm","T_deg"]:
        col="observed_"+target
        d[target]=pd.to_numeric(d[col],errors="coerce") if col in d else np.nan
        d.loc[nonnumeric,target]=np.nan
    d["uy_fark_cm"]=d.uy_max_cm-d.uy_min_cm
    invalid=d.uy_fark_cm.dropna()<0
    if invalid.any(): raise ValueError("Observed uy_max is smaller than observed uy_min.")
    d["reference_status"]=np.where(nonnumeric,"qualitative_only", "numeric_as_supplied")
    for t in TARGETS:
        d[t+"_abs_error"]=(d[t]-d[t+"_pred"]).abs()
        if t+"_lo90" in d:
            d[t+"_inside_band"]=pd.Series(np.where(d[t].notna(),((d[t]>=d[t+"_lo90"])&(d[t]<=d[t+"_hi90"])).astype(float),np.nan),index=d.index)
    return d
