"""CSV/JSON and read-only XLSX I/O. No Excel installation is required.

XLSX formula cells use saved Excel cached values. An uncached H/B cell can
be reconstructed by preprocessing; other required uncached cells fail clearly.
This is not an Excel formula evaluator. No macros or formulas are executed.
"""
from __future__ import annotations
import csv
import hashlib
import json
import posixpath
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd

NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_xlsx_matrix(path: str | Path, sheet: str | int = 0) -> list[list]:
    """Read a worksheet, preserving actual row/column positions."""
    with ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 256 * 1024 * 1024:
            raise ValueError("XLSX is too large for this reader (256 MiB expanded limit).")
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rel = {r.get("Id"): r.get("Target") for r in rels}
        sheets = wb.find("s:sheets", NS)
        nodes = list(sheets) if sheets is not None else []
        if isinstance(sheet, int):
            if sheet < 0 or sheet >= len(nodes):
                raise ValueError(f"Worksheet index {sheet} not available.")
            node = nodes[sheet]
        else:
            found = [s for s in nodes if s.get("name") == sheet]
            if not found:
                raise ValueError(f"Worksheet {sheet!r} not found. Available: {[s.get('name') for s in nodes]}")
            node = found[0]
        target = rel[node.get(f"{{{RNS}}}id")]
        name = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("s:si", NS):
                shared.append("".join(t.text or "" for t in si.findall(".//s:t", NS)))
        root = ET.fromstring(z.read(name))
        cells, last_row, last_col = {}, 0, 0
        for c in root.findall(".//s:sheetData/s:row/s:c", NS):
            coord = c.get("r", "")
            match = re.fullmatch(r"([A-Z]+)([0-9]+)", coord)
            if not match:
                continue
            col = 0
            for char in match[1]:
                col = col * 26 + ord(char) - 64
            row = int(match[2])
            val = c.find("s:v", NS)
            kind = c.get("t")
            if kind == "inlineStr":
                value = "".join(t.text or "" for t in c.findall(".//s:t", NS))
            elif val is None or val.text is None:
                value = None
            elif kind == "s":
                value = shared[int(val.text)]
            elif kind in {"str", "e"}:
                value = val.text
            elif kind == "b":
                value = bool(int(val.text))
            else:
                try:
                    value = float(val.text)
                    if value.is_integer():
                        value = int(value)
                except ValueError:
                    value = val.text
            if value is not None:
                cells[row - 1, col - 1] = value
                last_row, last_col = max(last_row, row), max(last_col, col)
        if last_row * last_col > 3_000_000:
            raise ValueError("Worksheet dimensions too large; remove remote formatted cells.")
        return [[cells.get((r, c)) for c in range(last_col)] for r in range(last_row)]


def read_table(path: str | Path, sheet: str | int = 0, header_row: int = 1) -> pd.DataFrame:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Input file not found: {path}")
    if path.suffix.lower() == ".xlsx":
        matrix = read_xlsx_matrix(path, sheet)
        if not matrix or not (1 <= header_row <= len(matrix)):
            raise ValueError("Empty worksheet or invalid header row.")
        header = matrix[header_row - 1]
        keep = [i for i, h in enumerate(header) if h not in [None, ""]]
        names = [str(header[i]).strip() for i in keep]
        if len(names) != len(set(names)):
            raise ValueError("Duplicate column names in worksheet header.")
        return pd.DataFrame([[r[i] for i in keep] for r in matrix[header_row:]], columns=names).dropna(how="all").reset_index(drop=True)
    if path.suffix.lower() not in {".csv", ".tsv"}:
        raise ValueError("Supported formats are .csv, .tsv and .xlsx, not .xls/.xlsm.")
    sample = path.read_text(encoding="utf-8-sig")[:10000]
    try:
        delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
    except csv.Error:
        delimiter = ","
    return pd.read_csv(path, sep=delimiter, encoding="utf-8-sig", float_precision="round_trip").dropna(how="all").reset_index(drop=True)


def write_table(df: pd.DataFrame, path: str | Path) -> None:
    """Excel-compatible UTF-8 CSV; no formula strings from untrusted Notes."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    safe = df.copy()
    for col in safe.select_dtypes(include=["object", "string"]).columns:
        safe[col] = safe[col].map(lambda x: "'" + x if isinstance(x, str) and x.startswith(("=", "+", "@")) else x)
    safe.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.17g")


def _clean(value):
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [_clean(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(value, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_clean(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
