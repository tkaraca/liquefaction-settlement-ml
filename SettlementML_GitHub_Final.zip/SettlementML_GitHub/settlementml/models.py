"""Explicit model configurations, target transformations and prediction contract."""
from __future__ import annotations
import platform
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesRegressor, ExtraTreesClassifier, RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neural_network import MLPRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.linear_model import Ridge
from .data import CATEGORICAL, CORE, DIRECT, TARGETS, features_for, engineer, scope_warnings
from .io import read_json, write_json


def environment():
    import scipy, matplotlib
    versions = {"python": platform.python_version(), "platform": platform.platform(), "numpy": np.__version__, "pandas": pd.__version__, "scikit-learn": sklearn.__version__, "scipy": scipy.__version__, "joblib": joblib.__version__, "matplotlib": matplotlib.__version__}
    from importlib.metadata import version, PackageNotFoundError
    for name in ("threadpoolctl", "xgboost", "lightgbm", "catboost"):
        try: versions[name] = version(name)
        except PackageNotFoundError: versions[name] = "not installed"
    return versions


def transform_targets(d, mode):
    y = d[DIRECT].to_numpy(float)
    if mode == "raw": return y
    if mode == "log1p": return np.log1p(y)
    if mode == "asinh50": return np.arcsinh(y/50.)
    if mode == "norm_log1p": return np.log1p(y/(d.B_m.to_numpy(float)[:,None]*100.))
    raise ValueError(f"Unknown target transformation: {mode}")


def inverse_targets(d, z, mode):
    z = np.asarray(z, dtype=float)
    with np.errstate(over="raise", invalid="raise"):
        if mode == "raw": y = z
        elif mode == "log1p": y = np.expm1(z)
        elif mode == "asinh50": y = 50. * np.sinh(z)
        elif mode == "norm_log1p": y = np.expm1(z) * (100. * d.B_m.to_numpy(float)[:,None])
        else: raise ValueError(f"Unknown target transformation: {mode}")
    if not np.isfinite(y).all(): raise ValueError("Nonfinite inverse-transformed predictions.")
    return np.maximum(y,0.)


def reconstruct(d, y):
    y = np.maximum(np.asarray(y, dtype=float), 0.)
    if y.shape != (len(d),2):
        raise ValueError(f"Expected two direct outputs; got {y.shape}.")
    return pd.DataFrame({"uy_min_cm_pred": y[:,0], "uy_fark_cm_pred": y[:,1], "uy_max_cm_pred": y[:,0]+y[:,1], "T_deg_pred": np.degrees(np.arctan(y[:,1]/(100.*d.B_m.to_numpy(float))))}, index=d.index)


def preprocessor(feature_set="core", scaled=False):
    features = features_for(feature_set)
    num = [c for c in features if c not in CATEGORICAL]
    return ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL), ("num", StandardScaler() if scaled else "passthrough", num)], remainder="drop")


def estimator(cfg, seed=None):
    seed = int(cfg["random_state"] if seed is None else seed)
    family = cfg.get("family", "ExtraTrees")
    jobs = cfg.get("n_jobs",2)
    if family in {"ExtraTrees", "RandomForest"}:
        cls = ExtraTreesRegressor if family == "ExtraTrees" else RandomForestRegressor
        model = cls(n_estimators=int(cfg.get("n_estimators",60)), min_samples_leaf=int(cfg.get("min_samples_leaf",1)), max_features=cfg.get("max_features",1.), random_state=seed, n_jobs=jobs)
    elif family == "Ridge":
        model = Ridge(alpha=cfg.get("ridge_alpha",1.))
    elif family.startswith("ANN"):
        hidden = (128,64) if "128" in family else (64,32)
        # No row-wise validation_fraction split: the entire outer training fold is
        # used and epochs are fixed. This differs from the historical ANN runs.
        model = MLPRegressor(hidden_layer_sizes=hidden, activation="relu", solver="adam", alpha=3e-3, learning_rate_init=1e-3 if hidden[0]==128 else 2e-3, max_iter=int(cfg.get("ann_max_iter",250)), early_stopping=False, random_state=seed)
    elif family == "XGBoost":
        from xgboost import XGBRegressor
        model = MultiOutputRegressor(XGBRegressor(n_estimators=80, max_depth=4, learning_rate=.04, subsample=.9, colsample_bytree=.9, reg_lambda=2., tree_method="hist", objective="reg:squarederror", random_state=seed,n_jobs=jobs), n_jobs=1)
    elif family == "LightGBM":
        from lightgbm import LGBMRegressor
        model = MultiOutputRegressor(LGBMRegressor(n_estimators=80, max_depth=-1, num_leaves=15, learning_rate=.04, min_child_samples=10, reg_lambda=1., random_state=seed,n_jobs=jobs,verbosity=-1),n_jobs=1)
    else:
        raise ValueError(f"Unknown model family: {family}")
    return Pipeline([("pre",preprocessor(cfg.get("feature_set","core"), family.startswith("ANN") or family=="Ridge")),("model",model)])


def fit_regressor(d, cfg, seed=None):
    features = features_for(cfg.get("feature_set","core"))
    X = engineer(d)[features]
    z = transform_targets(d,cfg.get("target_transform","raw"))
    # Experimental weight definition is explicit and limited to training labels.
    weights = np.where(d.T_deg.to_numpy()>cfg.get("high_response_T_deg",5.),3.,1.) if cfg.get("weighted") else None
    if cfg.get("family") == "CatBoost":
        from catboost import CatBoostRegressor
        model = CatBoostRegressor(iterations=120,depth=5,learning_rate=.04,loss_function="MultiRMSE",random_seed=int(seed if seed is not None else cfg["random_state"]),verbose=False,allow_writing_files=False,thread_count=cfg.get("n_jobs",2))
        model.fit(X, z, cat_features=CATEGORICAL, sample_weight=weights)
        return model
    model = estimator(cfg,seed)
    kwargs = {"model__sample_weight": weights} if weights is not None else {}
    model.fit(X,z,**kwargs)
    return model


def predict_regressor(model, d, cfg):
    features = features_for(cfg.get("feature_set","core"))
    z = model.predict(engineer(d)[features])
    return reconstruct(d,inverse_targets(d,z,cfg.get("target_transform","raw")))


def fit_detector(d,cfg,seed=None):
    y = (d.T_deg > cfg.get("high_response_T_deg",5.)).astype(int)
    model = Pipeline([("pre", preprocessor()), ("model",ExtraTreesClassifier(n_estimators=int(cfg.get("classifier_n_estimators",120)),class_weight="balanced",random_state=int(seed if seed is not None else cfg.get("classifier_seed",1888)),n_jobs=cfg.get("n_jobs",2)))])
    model.fit(d[CORE],y)
    return model


def detector_probability(model,d):
    classes = list(model.classes_)
    if 1 not in classes:
        return np.zeros(len(d))
    return model.predict_proba(d[CORE])[:,classes.index(1)]


def load_bundle(path):
    path = Path(path)
    meta_path = path.with_suffix(".metadata.json")
    if meta_path.exists():
        meta = read_json(meta_path)
        ver = meta.get("environment",{}).get("scikit-learn")
        if ver and ver != sklearn.__version__:
            raise RuntimeError(f"This trusted model was saved with scikit-learn {ver}; current version is {sklearn.__version__}. Install requirements.txt or train a new model. Do not suppress version warnings.")
    # Never load arbitrary Internet joblib files. See MODEL_CARD.md.
    b = joblib.load(path)
    if b.get("schema_version") != 1:
        raise ValueError("Not a SettlementML release bundle. Use the provided model or retrain.")
    return b


def save_bundle(bundle,path):
    path = Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    joblib.dump(bundle,path,compress=3)
    write_json({k:v for k,v in bundle.items() if k not in {"point_model","high_response_classifier"}},path.with_suffix(".metadata.json"))


def predict_bundle(bundle, d, interval_mode=None):
    cfg = bundle["config"]
    out = d.copy().reset_index(drop=True)
    pred = predict_regressor(bundle["point_model"],out,cfg)
    for c in pred: out[c] = pred[c].values
    probability = detector_probability(bundle["high_response_classifier"],out)
    out["high_response_probability"] = probability
    out["high_response_flag"] = (probability>=cfg["classifier_probability_threshold"]).astype(int)
    out["high_response_definition"] = f"T_deg > {cfg['high_response_T_deg']:g}; model score, not safety probability"
    mode = interval_mode or cfg.get("interval_mode","gated_diagnostic")
    if mode not in {"global","gated_diagnostic"}: raise ValueError("Unknown interval mode.")
    qmap = bundle.get("residual_quantiles",{})
    out["interval_source"] = np.where(out.high_response_flag.eq(1) & (mode=="gated_diagnostic"),"upper_response_residuals","global_residuals")
    for t in TARGETS:
        if t not in qmap:
            continue
        q = np.where(out.interval_source.eq("upper_response_residuals"),qmap[t]["upper_response"],qmap[t]["global"])
        out[t+"_lo90"] = np.maximum(0.,out[t+"_pred"]-q)
        out[t+"_hi90"] = out[t+"_pred"]+q
    warn = scope_warnings(out,bundle["data_metadata"])
    for c in warn: out[c]=warn[c].values
    rr=bundle["data_metadata"]["response_ranges"]
    out["outside_training_response_flag"] = np.logical_or.reduce([out[t+"_pred"]>rr[t]["max"] for t in TARGETS]).astype(int)
    out["interval_note"] = "Nominal 90% OOF residual diagnostic band; not independent coverage validation or a safety interval. Tolerance rates are separate."
    out["model_release"] = bundle.get("release","1.0.0")
    return out
