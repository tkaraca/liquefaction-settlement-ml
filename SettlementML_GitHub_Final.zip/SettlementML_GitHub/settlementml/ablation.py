"""Predefined controlled ablations; historical tables are never overwritten."""
from pathlib import Path
from copy import deepcopy
import time
import numpy as np
import pandas as pd
from .data import ENGINEERED,TARGETS
from .io import write_table,write_json,read_table,read_json
from .workflows import load_training,grouped_cv,frame_signature
from .metrics import regression_metrics,upper_definition,upper_mask
from .models import environment


def configuration_grid(suite):
    features=[("ExtraTrees",f,"raw",False) for f in ["core"]+["core+"+x for x in ENGINEERED]+["selected","full_engineered"]]
    ann=[(fam,"core",transform,False) for fam in ["ANN64_32","ANN128_64"] for transform in ["raw","log1p","asinh50","norm_log1p"]]
    target=[("ExtraTrees","core",t,w) for t in ["raw","log1p","asinh50","norm_log1p"] for w in [False,True]]
    families=[(fam,"core",t,False) for fam in ["RandomForest","Ridge","XGBoost","LightGBM","CatBoost"] for t in ["raw","log1p"]]
    if suite=="features":return features
    if suite=="ann":return ann
    if suite=="targets":return target
    if suite=="families":return families
    if suite=="all":return list(dict.fromkeys(features+ann+target+families))
    if suite=="smoke":return [features[0],("ExtraTrees","selected","raw",False),("ANN64_32","core","log1p",False)]
    raise ValueError(suite)


def run_ablation(input_path,outdir,cfg,suite="features",resume=False):
    d,_=load_training(input_path);out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    metrics=[];status=[];records={};definition=upper_definition(d,cfg)
    for fam,feat,tf,wt in configuration_grid(suite):
        local=deepcopy(cfg);local.update(family=fam,feature_set=feat,target_transform=tf,weighted=wt)
        name=f"{fam}_{feat}_{tf}_{'weighted' if wt else 'unweighted'}"
        start=time.perf_counter();print(name,flush=True)
        cached=out/"oof"/(name.replace('+','_plus_')+".csv")
        cached_config=out/"configurations"/(name.replace('+','_plus_')+".json")
        reused = False
        try:
            if resume and cached.exists() and cached_config.exists():
                prior=read_json(cached_config)
                reused = True
                if prior.get("config")!=local or prior.get("canonical_signature")!=frame_signature(d):
                    raise ValueError("Ablation resume cache has different data/configuration. Use another output directory.")
                oof=read_table(cached);folds=pd.DataFrame(prior["folds"]);warnings=prior["fit_warnings"]
                print("  Reused completed configuration (matching data and parameters).",flush=True)
            else:
                oof,folds,warnings=grouped_cv(d,local,with_classifier=False)
        except ImportError as e:
            status.append({"configuration":name,"status":"SKIPPED_OPTIONAL_DEPENDENCY","details":str(e)})
            continue
        met=regression_metrics(oof,masks={"all":np.ones(len(d),bool),"upper_response_q90_union":upper_mask(d,definition)})
        met["configuration"]=name;met["family"]=fam;met["feature_set"]=feat;met["target_transform"]=tf;met["weighted"]=wt
        metrics.append(met);records[name]=oof
        write_table(oof,out/"oof"/(name.replace('+','_plus_')+".csv"))
        write_json({"config":local,"canonical_signature":frame_signature(d),"fit_warnings":warnings,"folds":folds.to_dict('records')},out/"configurations"/(name.replace('+','_plus_')+".json"))
        status.append({"configuration":name,"status":"COMPLETED","execution":"REUSED_MATCHING_CACHE" if reused else "FITTED_THIS_INVOCATION","invocation_seconds":time.perf_counter()-start})
        write_table(pd.concat(metrics,ignore_index=True),out/"ablation_metrics.csv")
        write_table(pd.DataFrame(status),out/"run_status.csv")
    write_json({"suite":suite,"configuration_count":len(configuration_grid(suite)),"completed":len(metrics),"config":cfg,"environment":environment(),"canonical_signature":frame_signature(d),"notes":["Identical grouped splits and CV seeds across configurations.","ANN fixed epochs with early_stopping=False: no row-wise hidden validation split.","These are controlled release reruns, not a relabelling of historical benchmark scores.","No automatic selection on external case-study errors. The supplied core final model is not changed by ablation."]},out/"ablation_manifest.json")
    # Matched, cluster-resampled differences for feature additions, exploratory only.
    baseline="ExtraTrees_core_raw_unweighted"
    if baseline in records and len(records)>1:
        base=records[baseline]; groups=d.AnalizNo.to_numpy(); unique,inv=np.unique(groups,return_inverse=True);nrows=np.bincount(inv)
        rng=np.random.default_rng(5701);boot=rng.integers(0,len(unique),size=(1000,len(unique)))
        ci=[]
        for name,r in records.items():
            if name==baseline:continue
            for t in TARGETS:
                delta=(abs(r[t]-r[t+"_pred"])-abs(base[t]-base[t+"_pred"])).to_numpy()
                sums=np.bincount(inv,weights=delta)
                means=sums[boot].sum(axis=1)/nrows[boot].sum(axis=1)
                ci.append({"configuration":name,"target":t,"delta_MAE_vs_core":float(delta.mean()),"cluster_bootstrap_lo95":float(np.quantile(means,.025)),"cluster_bootstrap_hi95":float(np.quantile(means,.975)),"cluster":"AnalizNo","interpretation":"Exploratory paired error comparison; not multiple-testing-adjusted or nested model-selection inference"})
        write_table(pd.DataFrame(ci),out/"paired_ablation_differences.csv")
    print(f"Ablation completed: {len(metrics)} configurations -> {out}",flush=True)
