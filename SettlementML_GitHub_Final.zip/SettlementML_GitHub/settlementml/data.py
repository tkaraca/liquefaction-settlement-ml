"""Input-only feature construction, strict validation and original-table import."""
from __future__ import annotations
import unicodedata
from pathlib import Path
import numpy as np
import pandas as pd
from .io import read_table, read_xlsx_matrix

CATEGORICAL = ["Senaryo", "Yerlesim", "ProfilNo", "BodrumDurumu", "BinaKonumu"]
NUMERIC = ["BinaSayisi", "CAV_cm_s", "EtkinSure_D5_D95_s", "AriasIntensity_Ia", "B_m", "H_m", "H_B", "Q_kPa", "w_m", "Df_m"]
CORE = CATEGORICAL + NUMERIC
INPUTS = ["Senaryo", "ProfilNo", "CAV_cm_s", "EtkinSure_D5_D95_s", "AriasIntensity_Ia", "B_m", "H_m", "H_B", "Q_kPa", "w_m", "Df_m", "BinaKonumu"]
TARGETS = ["uy_min_cm", "uy_fark_cm", "uy_max_cm", "T_deg"]
DIRECT = ["uy_min_cm", "uy_fark_cm"]
ENGINEERED = ["w_over_B", "w_over_H", "H_times_Q", "SlenderLoad", "Intensity_CAV_Ia", "Intensity_CAV_Duration", "Arias_per_Duration", "KonumIndex", "KenarBina"]
COMPACT = ["w_over_B", "H_times_Q", "KonumIndex", "KenarBina"]
SCENARIOS = {
    "Ayrık (Tekil) Bina": (1, "Tekil"),
    "İki Bina Ayrık": (2, "Ayrık"),
    "İki Bina Bitişik": (2, "Bitişik"),
    "Üç Bina Ayrık": (3, "Ayrık"),
    "Üç Bina Bitişik": (3, "Bitişik"),
}
POSITIONS = {1: ["Sol Bina"], 2: ["Sol Bina", "Sag Bina"], 3: ["Sol Bina", "Orta Bina", "Sag Bina"]}
ALIASES = {
    "Profil": "ProfilNo", "Profil No": "ProfilNo", "CAV": "CAV_cm_s", "Etkin süre": "EtkinSure_D5_D95_s",
    "EtkinSure": "EtkinSure_D5_D95_s", "Arias": "AriasIntensity_Ia", "AriasIntensity": "AriasIntensity_Ia",
    "B": "B_m", "H": "H_m", "H/B": "H_B", "Q": "Q_kPa", "w": "w_m", "Df": "Df_m", "Bina Konumu": "BinaKonumu",
    "observed_uy_min_cm_optional": "observed_uy_min_cm", "observed_uy_max_cm_optional": "observed_uy_max_cm",
    "observed_T_deg_optional": "observed_T_deg", "obs_uy_min_cm": "observed_uy_min_cm",
    "obs_uy_max_cm": "observed_uy_max_cm", "obs_T_deg": "observed_T_deg",
}
ORIGINAL_COLS = ["AnalizNo", "Aciklama", "ProfilNo", "CAV_cm_s", "EtkinSure_D5_D95_s", "AriasIntensity_Ia", "B_m", "H_m", "H_B", "Q_kPa", "w_m", "Df_m", "Sol_uy_min_cm", "Sol_uy_max_cm", "Sol_T_deg", "Orta_uy_min_cm", "Orta_uy_max_cm", "Orta_T_deg", "Sag_uy_min_cm", "Sag_uy_max_cm", "Sag_T_deg"]


def token(x) -> str:
    if pd.isna(x):
        return ""
    t = str(x).replace("\xa0", " ").strip().lower().replace("ı", "i")
    t = "".join(c for c in unicodedata.normalize("NFD", t) if not unicodedata.combining(c))
    return " ".join(t.split())


def scenario(x) -> str:
    key = token(x)
    mapping = {token(s): s for s in SCENARIOS}
    mapping.update({"ayrik tekil bina": "Ayrık (Tekil) Bina", "tekil bina": "Ayrık (Tekil) Bina"})
    if key not in mapping:
        raise ValueError(f"Unknown Senaryo {x!r}. Allowed: {list(SCENARIOS)}")
    return mapping[key]


def position(x) -> str:
    key = token(x)
    mapping = {"sol": "Sol Bina", "sol bina": "Sol Bina", "orta": "Orta Bina", "orta bina": "Orta Bina", "sag": "Sag Bina", "sag bina": "Sag Bina", "all": "ALL"}
    if key not in mapping:
        raise ValueError(f"Unknown/missing BinaKonumu {x!r}. Use Sol Bina / Orta Bina / Sag Bina.")
    return mapping[key]


def _number(s: pd.Series) -> pd.Series:
    if s.dtype == object:
        s = s.map(lambda v: str(v).strip().replace(",", ".") if pd.notna(v) else v)
    return pd.to_numeric(s, errors="coerce")


def canonical_columns(frame):
    d = frame.copy()
    d.columns = [ALIASES.get(str(c).strip(), str(c).strip()) for c in d.columns]
    if d.columns.duplicated().any():
        raise ValueError("Duplicate columns after alias mapping. Keep one column per variable.")
    return d


def expand_wide_inputs(d: pd.DataFrame) -> pd.DataFrame:
    """Only homogeneous per-case inputs may be expanded to all positions."""
    rows = []
    for i, r in d.iterrows():
        s = scenario(r.get("Senaryo"))
        for pos in POSITIONS[SCENARIOS[s][0]]:
            row = r.to_dict()
            row["BinaKonumu"] = pos
            row["CaseID"] = row.get("CaseID") if pd.notna(row.get("CaseID")) else f"CASE_{i+1:03d}"
            # A shared BuildingID cannot identify multiple buildings.
            row["BuildingID"] = f"{row['CaseID']}_{token(pos).split()[0]}"
            rows.append(row)
    return pd.DataFrame(rows)


def prepare_inputs(frame: pd.DataFrame, fmt="long", strict_cases=True) -> tuple[pd.DataFrame, list[dict]]:
    d = canonical_columns(frame).dropna(how="all").reset_index(drop=True)
    if d.empty:
        raise ValueError("No input rows supplied.")
    if "Senaryo" not in d:
        raise ValueError("Missing Senaryo. A building code is not a scenario class.")
    if fmt == "wide":
        if any(c.startswith("observed_") and d[c].notna().any() for c in d):
            raise ValueError("Wide input cannot replicate a single observed output to all buildings. Use long format.")
        d = expand_wide_inputs(d)
    if "BinaKonumu" in d and d["BinaKonumu"].map(token).eq("all").any():
        rows = []
        for _, r in d.iterrows():
            if token(r["BinaKonumu"]) == "all":
                rows.append(expand_wide_inputs(pd.DataFrame([r])))
            else:
                rows.append(pd.DataFrame([r]))
        d = pd.concat(rows, ignore_index=True)
    required = [c for c in INPUTS if c not in {"H_B", "w_m"}]
    missing = [c for c in required if c not in d]
    if missing:
        raise ValueError(f"Missing input columns: {missing}")
    events = []
    d["Senaryo"] = d["Senaryo"].map(scenario)
    d["ProfilNo"] = d["ProfilNo"].map(lambda x: str(x).strip().upper())
    if not d["ProfilNo"].isin(["P1", "P2"]).all():
        raise ValueError("ProfilNo must be P1 or P2. Unseen soil profiles are unsupported categories.")
    d["BinaKonumu"] = d["BinaKonumu"].map(position)
    d["BinaSayisi"] = d["Senaryo"].map(lambda s: SCENARIOS[s][0])
    d["Yerlesim"] = d["Senaryo"].map(lambda s: SCENARIOS[s][1])
    for col in NUMERIC:
        if col not in d:
            d[col] = np.nan
        d[col] = _number(d[col])
    for c in ["B_m", "H_m", "EtkinSure_D5_D95_s"]:
        if (d[c].isna() | (d[c] <= 0) | ~np.isfinite(d[c])).any():
            raise ValueError(f"{c} must be finite and greater than zero.")
    hb = d["H_m"] / d["B_m"]
    conflict = d["H_B"].notna() & (abs(d["H_B"] - hb) > 5e-4)
    if conflict.any():
        raise ValueError(f"H_B inconsistent with H_m/B_m at data rows {(np.flatnonzero(conflict)+1).tolist()}")
    for i in np.flatnonzero(d["H_B"].isna() | (abs(d["H_B"]-hb)>1e-12)):
        events.append({"row": int(i+1), "field": "H_B", "action": "recomputed_H_over_B", "supplied": d.at[i,"H_B"], "used": hb.iloc[i]})
    d["H_B"] = hb
    null_spacing = d["w_m"].isna()
    if (null_spacing & d["Yerlesim"].eq("Ayrık")).any():
        raise ValueError("Missing w_m for detached multi-building rows. Do not substitute zero.")
    for i in np.flatnonzero(null_spacing):
        events.append({"row": int(i+1), "field": "w_m", "action": "not_applicable_spacing_code_zero", "supplied": None, "used": 0.0})
    d.loc[null_spacing, "w_m"] = 0.0
    if ((d["Yerlesim"] != "Ayrık") & (d["w_m"] != 0)).any():
        raise ValueError("Tekil/Bitişik uses model code w_m=0. Preserve a physical gap separately in w_physical_m; do not silently relabel the scenario.")
    if (d["Yerlesim"].eq("Ayrık") & (d["w_m"] <= 0)).any():
        raise ValueError("Detached multi-building inputs need a positive physical w_m.")
    if not d["Df_m"].isin([1., 3.]).all():
        raise ValueError("Supported Df_m values: 1 (Bodrumsuz), 3 (Bodrumlu). No reversed mapping.")
    d["BodrumDurumu"] = d["Df_m"].map({1.: "Bodrumsuz", 3.: "Bodrumlu"})
    if not np.isfinite(d[NUMERIC].to_numpy(float)).all():
        raise ValueError("Required numeric input contains missing/nonfinite values.")
    if (d[["CAV_cm_s", "AriasIntensity_Ia", "Q_kPa", "w_m"]] < 0).any().any():
        raise ValueError("CAV, Arias, pressure and spacing cannot be negative.")
    for i, r in d.iterrows():
        if r.BinaKonumu not in POSITIONS[int(r.BinaSayisi)]:
            raise ValueError(f"Invalid position for scenario at data row {i+1}: {r.BinaKonumu}")
    if "RecordID" not in d:
        if "AnalizNo" in d:
            d["RecordID"] = [f"A{a}_{token(p).split()[0]}" for a,p in zip(d.AnalizNo,d.BinaKonumu)]
        elif all(c in d for c in ["CaseID", "BuildingID"]):
            d["RecordID"] = [f"{str(a).strip()}::{str(b).strip()}" for a,b in zip(d.CaseID,d.BuildingID)]
        else:
            d["RecordID"] = [f"ROW_{i+1:04d}" for i in range(len(d))]
    if d["RecordID"].isna().any() or d["RecordID"].astype(str).duplicated().any():
        raise ValueError("RecordID must be present and unique within a file.")
    if "CaseID" in d:
        for case, group in d.groupby("CaseID", dropna=False, sort=False):
            for scen, g in group.groupby("Senaryo", sort=False):
                n = SCENARIOS[scen][0]
                if n == 1:
                    continue  # C34/C35/C36 are independent singles, not one three-building system.
                actual = list(g.BinaKonumu)
                if len(actual) != n or set(actual) != set(POSITIONS[n]):
                    msg = f"Incomplete or duplicated positions in {case} / {scen}: {actual}; expected {POSITIONS[n]}"
                    if strict_cases:
                        raise ValueError(msg)
                    events.append({"row": None, "field": "BinaKonumu", "action": "partial_case_warning", "message": msg})
    return d, events


def engineer(d: pd.DataFrame) -> pd.DataFrame:
    d = d.copy()
    d["w_over_B"] = d.w_m / d.B_m
    d["w_over_H"] = d.w_m / d.H_m
    d["H_times_Q"] = d.H_m * d.Q_kPa
    d["SlenderLoad"] = d.H_B * d.Q_kPa
    d["Intensity_CAV_Ia"] = d.CAV_cm_s * d.AriasIntensity_Ia
    d["Intensity_CAV_Duration"] = d.CAV_cm_s * d.EtkinSure_D5_D95_s
    d["Arias_per_Duration"] = d.AriasIntensity_Ia / d.EtkinSure_D5_D95_s
    d["KonumIndex"] = d.BinaKonumu.map({"Sol Bina": 1, "Orta Bina": 2, "Sag Bina": 3})
    d["KenarBina"] = d.BinaKonumu.isin(["Sol Bina", "Sag Bina"]).astype(int)
    return d


def features_for(name: str):
    if name == "core":
        return CORE.copy()
    if name == "selected":
        return CORE + COMPACT
    if name == "full_engineered":
        return CORE + ENGINEERED
    if name.startswith("core+") and name[5:] in ENGINEERED:
        return CORE + [name[5:]]
    raise ValueError(f"Unknown feature set: {name}")


def training_table(frame: pd.DataFrame, qc_policy=None):
    d, events = prepare_inputs(frame, strict_cases=False)
    if "AnalizNo" not in d:
        raise ValueError("Training/validation requires AnalizNo for group splitting.")
    if d.AnalizNo.isna().any():
        raise ValueError("AnalizNo cannot be missing.")
    # Preserve numeric group IDs and stable source order for grouped CV.
    ids = pd.to_numeric(d.AnalizNo, errors="coerce")
    if ids.notna().all():
        d["AnalizNo"] = ids.astype(int) if (ids % 1 == 0).all() else ids
    for c in ["uy_min_cm", "uy_max_cm"]:
        if c not in d:
            raise ValueError(f"Training target {c} is required.")
        d[c] = _number(d[c])
    if not np.isfinite(d[["uy_min_cm", "uy_max_cm"]].values).all():
        raise ValueError("Missing/nonfinite training labels. Do not train on unknown observations.")
    if ((d.uy_min_cm < 0) | (d.uy_max_cm < d.uy_min_cm)).any():
        raise ValueError("This convention needs 0 <= uy_min_cm <= uy_max_cm. Check displacement signs/units.")
    # Never read old predictions/regime labels as model features or training targets.
    d["uy_fark_cm"] = d.uy_max_cm - d.uy_min_cm
    formula = np.degrees(np.arctan(d.uy_fark_cm / (100 * d.B_m)))
    if "T_deg" not in d:
        d["T_deg"] = formula
        events.append({"action": "T_derived_from_displacements", "field": "T_deg"})
    else:
        d["T_deg"] = _number(d.T_deg)
        if not np.isfinite(d.T_deg).all():
            raise ValueError("Missing/nonfinite T_deg training label.")
        if abs(d.T_deg-formula).max() > 0.02:
            raise ValueError("Training T_deg conflicts with atan(delta/(100*B)); check units/formula.")
    rejected = d.iloc[:0].copy()
    if qc_policy:
        valid = (d.uy_max_cm <= qc_policy["max_uy_max_cm"]) & (d.T_deg <= qc_policy["max_T_deg"])
        if qc_policy.get("mode", "observation") == "analysis":
            valid = ~d.AnalizNo.isin(d.loc[~valid,"AnalizNo"])
        rejected = d.loc[~valid].copy()
        d = d.loc[valid].copy()
        events.append({"action": "explicit_expert_qc_policy", "removed": len(rejected), "retained": len(d), "policy": qc_policy})
    return d.reset_index(drop=True), rejected, events


def original_to_long(path, sheet=0, start_row=4):
    """Historical A:U wide layout with three header rows; preserves original ExcelRow."""
    matrix = read_xlsx_matrix(path, sheet)
    rows, last_description = [], None
    for i, values in enumerate(matrix[start_row-1:], start_row):
        if not values or values[0] in [None, ""]:
            continue
        values = (values + [None] * len(ORIGINAL_COLS))[:len(ORIGINAL_COLS)]
        r = dict(zip(ORIGINAL_COLS, values))
        if r["Aciklama"] not in [None, ""]:
            last_description = r["Aciklama"]
        r["Senaryo"] = scenario(last_description)
        for prefix, pos in [("Sol", "Sol Bina"), ("Orta", "Orta Bina"), ("Sag", "Sag Bina")]:
            names = [f"{prefix}_{c}" for c in ["uy_min_cm", "uy_max_cm", "T_deg"]]
            vals = [r[n] for n in names]
            if all(v in [None, ""] for v in vals):
                continue
            if any(v in [None, ""] for v in vals):
                raise ValueError(f"Partial output block at Excel row {i}, {prefix}.")
            row = {c: r[c] for c in ORIGINAL_COLS[:12]}
            row.update(Senaryo=r["Senaryo"], ExcelRow=i, BinaKonumu=pos)
            row.update(dict(zip(["uy_min_cm", "uy_max_cm", "T_deg"], vals)))
            rows.append(row)
    return pd.DataFrame(rows)


def range_metadata(d):
    pairs = d[["B_m", "H_m", "Q_kPa", "Df_m"]].drop_duplicates()
    return {
        "numeric_ranges": {c: {"min": float(d[c].min()), "max": float(d[c].max())} for c in NUMERIC},
        "response_ranges": {c: {"min": float(d[c].min()), "max": float(d[c].max())} for c in TARGETS},
        "category_support": {c: sorted(d[c].astype(str).unique().tolist()) for c in CATEGORICAL},
        "scenario_spacing_ranges": {s: {"min": float(g.w_m.min()), "max": float(g.w_m.max())} for s,g in d.groupby("Senaryo")},
        "n_df_pairs": [list(x) for x in d[["BinaSayisi", "Df_m"]].drop_duplicates().itertuples(index=False, name=None)],
        "geometry_load_combinations": pairs.to_dict("records"),
        "numeric_support_levels": {c: sorted(d[c].unique().astype(float).tolist()) for c in ["B_m", "H_m", "H_B", "Q_kPa", "w_m", "Df_m"]},
        "pressure_height_ratio": float(np.median(d.Q_kPa/d.H_m)) if np.ptp(d.Q_kPa/d.H_m) < 1e-7 else None,
    }


def scope_warnings(d, metadata):
    rows = []
    for _, r in d.iterrows():
        notes, outside, unseen = [], [], []
        for col, ran in metadata["numeric_ranges"].items():
            v = float(r[col])
            if v < ran["min"]-1e-9 or v > ran["max"]+1e-9:
                outside.append(col)
                notes.append(f"{col}={v:.6g} outside [{ran['min']:.6g}, {ran['max']:.6g}]")
        for col, levels in metadata.get("numeric_support_levels", {}).items():
            if col not in outside and not any(np.isclose(float(r[col]), v, rtol=0, atol=1e-8) for v in levels):
                unseen.append(col)
        ran = metadata.get("scenario_spacing_ranges", {}).get(r.Senaryo)
        if ran and not ran["min"]-1e-9 <= r.w_m <= ran["max"]+1e-9:
            notes.append(f"w_m={r.w_m:g} outside scenario-specific spacing [{ran['min']:g}, {ran['max']:g}]")
        if [int(r.BinaSayisi), float(r.Df_m)] not in metadata.get("n_df_pairs", []):
            notes.append("building_count/embedment combination not present in training")
        ratio = metadata.get("pressure_height_ratio")
        if ratio is not None and not np.isclose(r.Q_kPa/r.H_m, ratio, rtol=1e-6):
            notes.append("Q/H differs from the coupled loading rule in the development data")
        if unseen:
            notes.append("inside marginal bounds but not an exact training level: " + ", ".join(unseen))
        rows.append({"outside_training_range_flag": int(bool(outside)), "outside_training_features": "; ".join(outside), "unseen_training_levels": "; ".join(unseen), "scope_notes": "; ".join(notes)})
    out = pd.DataFrame(rows)
    # Heterogeneous neighbour properties are not explicit predictors in the original model.
    if "CaseID" in d:
        for case, g in d.groupby("CaseID", sort=False):
            multi = g[g.BinaSayisi>1]
            if len(multi)>1 and any(multi[c].nunique()>1 for c in ["B_m", "H_m", "Q_kPa", "Df_m"]):
                out.loc[multi.index,"scope_notes"] += "; heterogeneous neighbour properties not explicitly encoded; row-wise demonstration only"
    return out
