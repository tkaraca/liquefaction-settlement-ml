"""Additive linear-spline regression with quantile knots and ridge penalty.

This is not Friedman's adaptive MARS algorithm and is not fitted to ExtraTrees
predictions. It is a separate empirical baseline fitted to observed targets.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from .data import CATEGORICAL,NUMERIC,CORE,DIRECT
from .models import reconstruct
from .io import write_table,write_json
from .metrics import regression_metrics
from .workflows import load_training


class QuantileHingeBasis(BaseEstimator,TransformerMixin):
    def __init__(self,quantiles=(.25,.5,.75)):
        self.quantiles=quantiles
    def fit(self,X,y=None):
        X=np.asarray(X,float)
        self.n_features_in_=X.shape[1]
        self.knots_=[np.unique(np.quantile(X[:,j],self.quantiles)) for j in range(X.shape[1])]
        return self
    def transform(self,X):
        X=np.asarray(X,float)
        parts=[X]
        for j,knots in enumerate(self.knots_):
            for c in knots:
                parts.extend([np.maximum(0,X[:,j:j+1]-c),np.maximum(0,c-X[:,j:j+1])])
        return np.hstack(parts)
    def get_feature_names_out(self,input_features=None):
        names=list(input_features) if input_features is not None else [f"x{j}" for j in range(self.n_features_in_)]
        out=names.copy()
        for f,knots in zip(names,self.knots_):
            for c in knots:out.extend([f"max(0,{f}-{c:.12g})",f"max(0,{c:.12g}-{f})"])
        return np.array(out,dtype=object)


def hinge_model(alpha=10.,linear_only=False):
    numeric=StandardScaler() if linear_only else Pipeline([("hinge",QuantileHingeBasis()),("scale",StandardScaler())])
    return Pipeline([("pre",ColumnTransformer([("cat",OneHotEncoder(handle_unknown="ignore",sparse_output=False),CATEGORICAL),("num",numeric,NUMERIC)])),("ridge",Ridge(alpha=alpha))])


def fit_hinge_report(input_path,outdir,n_splits=5):
    d,_=load_training(input_path);out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    metrics=[]
    for linear in [True,False]:
        name="linear_ridge" if linear else "quantile_knot_linear_spline_ridge"
        preds=np.zeros((len(d),2))
        for tr,te in GroupKFold(n_splits).split(d,d[DIRECT],d.AnalizNo):
            m=hinge_model(10.,linear);m.fit(d[CORE].iloc[tr],d[DIRECT].iloc[tr]);preds[te]=m.predict(d[CORE].iloc[te])
        rec=reconstruct(d,preds);oof=pd.concat([d,rec],axis=1)
        met=regression_metrics(oof);met["model"]=name;metrics.append(met)
        write_table(oof,out/(name+"_oof.csv"))
    model=hinge_model();model.fit(d[CORE],d[DIRECT]);joblib.dump(model,out/"linear_spline_ridge.joblib",compress=3)
    pre=model.named_steps['pre'];reg=model.named_steps['ridge'];numeric=pre.named_transformers_['num'];h=numeric.named_steps['hinge'];scale=numeric.named_steps['scale']
    cat=pre.named_transformers_['cat'];catnames=cat.get_feature_names_out(CATEGORICAL)
    terms=[]
    for f,categories in zip(CATEGORICAL,cat.categories_):
        for value in categories:terms.append({"term":f+"="+str(value),"kind":"category","input":f,"category":str(value),"knot":None,"mean":0.,"scale":1.})
    specs=[{"term":f,"kind":"linear","input":f,"category":None,"knot":None} for f in NUMERIC]
    for f,knots in zip(NUMERIC,h.knots_):
        for c in knots:
            specs.extend([{"term":f"max(0,{f}-{c:.12g})","kind":"right_hinge","input":f,"category":None,"knot":float(c)}, {"term":f"max(0,{c:.12g}-{f})","kind":"left_hinge","input":f,"category":None,"knot":float(c)}])
    for spec,mean,sd in zip(specs,scale.mean_,scale.scale_):
        terms.append({**spec,"mean":float(mean),"scale":float(sd)})
    formula={"method":"Additive piecewise-linear regression with quantile knots and L2 penalty", "ridge_alpha":10.,"targets":{},"terms":terms,"notes":["Numeric bases standardized; one-hot categories unscaled.","Redundant bases, H/Q coupling and redundant categories make individual coefficients noncausal and representation-dependent.","Knots fitted on training folds for OOF; displayed coefficients come from refitting all development data."]}
    rows=[]
    for k,t in enumerate(DIRECT):
        coeff=reg.coef_[k];rawcoef=coeff/np.array([s['scale'] for s in terms]);rawint=float(reg.intercept_[k]-sum(coeff[i]*terms[i]['mean']/terms[i]['scale'] for i in range(len(terms))))
        formula["targets"][t]={"intercept_standardized":float(reg.intercept_[k]),"coefficients_standardized":coeff.tolist(),"intercept_raw_basis":rawint,"coefficients_raw_basis":rawcoef.tolist()}
        for spec,c,cr in zip(terms,coeff,rawcoef):rows.append({"target":t,**spec,"coefficient_standardized_basis":c,"coefficient_raw_basis":cr})
    write_table(pd.DataFrame(rows),out/"coefficients.csv")
    write_table(pd.DataFrame([{"feature":f,"q25":np.quantile(d[f],.25),"q50":np.quantile(d[f],.5),"q75":np.quantile(d[f],.75)} for f in NUMERIC]),out/"knots.csv")
    write_table(pd.concat(metrics,ignore_index=True),out/"baseline_metrics.csv")
    write_json(formula,out/"formula.json")
    # Verify exported equation is genuinely sufficient for implementation.
    analytical=predict_formula(formula,d);native=reconstruct(d,model.predict(d[CORE]))
    error=float(np.max(abs(analytical.values-native.values)))
    if error>1e-8:raise AssertionError(f"Exported formula mismatch: {error}")
    write_json({"max_exported_formula_prediction_difference":error,"n_verified":len(d)},out/"formula_export_check.json")
    print(f"Hinge/linear baselines, coefficients and executable formula exported -> {out}",flush=True)


def predict_formula(formula,d):
    basis=[]
    for spec in formula['terms']:
        x=d[spec['input']]
        if spec['kind']=='category':v=x.astype(str).eq(spec['category']).astype(float).to_numpy()
        elif spec['kind']=='linear':v=x.to_numpy(float)
        elif spec['kind']=='right_hinge':v=np.maximum(0,x.to_numpy(float)-spec['knot'])
        else:v=np.maximum(0,spec['knot']-x.to_numpy(float))
        basis.append(v)
    X=np.column_stack(basis)
    y=np.column_stack([formula['targets'][t]['intercept_raw_basis']+X@np.asarray(formula['targets'][t]['coefficients_raw_basis']) for t in DIRECT])
    return reconstruct(d,y)
