"""Public workflows. All learned preprocessing stays within training folds."""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import time
import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from . import __version__
from .data import CORE, DIRECT, TARGETS, INPUTS, ENGINEERED, training_table, prepare_inputs, original_to_long, range_metadata, features_for, scope_warnings
from .io import read_table, write_table, write_json, read_json, sha256
from .models import fit_regressor, predict_regressor, fit_detector, detector_probability, predict_bundle, save_bundle, load_bundle, environment
from .metrics import regression_metrics, tolerance_metrics, residual_quantiles, upper_definition, upper_mask, coverage_metrics, observed_reference


def frame_signature(d):
    """Stable fingerprint of the model-relevant ordered rows, rounded to 12 digits.

    Original file bytes have a separate SHA256; this signature intentionally
    ignores cosmetic CSV formatting and irrelevant Notes/old prediction columns.
    """
    cols=["AnalizNo"]+CORE+TARGETS if "AnalizNo" in d else CORE+TARGETS
    text=d[cols].to_csv(index=False,float_format="%.12g",lineterminator="\n")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_training(path):
    d,rejected,events=training_table(read_table(path))
    if len(rejected): raise AssertionError("Unexpected automatic target filtering.")
    return d,events


def preprocess(input_path,outdir,fmt="long",sheet=0,start_row=4,qc_policy=None):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    frame=original_to_long(input_path,sheet,start_row) if fmt=="original" else read_table(input_path,sheet)
    policy=read_json(qc_policy) if qc_policy else None
    d,rejected,events=training_table(frame,policy)
    # Drop all historical OOF predictions, regime assignments and extra features.
    cols=[c for c in ["RecordID","ExcelRow","AnalizNo"]+INPUTS+TARGETS if c in d]
    write_table(d[cols],outdir/"training_long.csv")
    write_table(rejected,outdir/"excluded_records.csv")
    write_json({"rows":len(d),"analysis_groups":int(d.AnalizNo.nunique()),"excluded":len(rejected),"file_sha256":sha256(input_path),"input_filename":Path(input_path).name,"canonical_signature":frame_signature(d),"events":events,"policy":policy,"data_metadata":range_metadata(d)},outdir/"preprocess_audit.json")
    # Numerically check geometric identities, duplication and representation counts.
    repeated=d.duplicated(CORE,keep=False)
    conflicts=0
    if repeated.any():
        g=d.loc[repeated].groupby(CORE,dropna=False)[DIRECT].nunique()
        conflicts=int((g>1).any(axis=1).sum())
    audit={"target_columns_in_core":sorted(set(CORE)&set(TARGETS)),"id_columns_in_core":sorted(set(CORE)&{"AnalizNo","RecordID","CaseID","BuildingID"}),"duplicated_feature_rows":int(repeated.sum()),"conflicting_duplicate_feature_groups":conflicts,"max_H_B_difference":float(abs(d.H_B-d.H_m/d.B_m).max()),"max_formula_T_difference_deg":float(abs(d.T_deg-np.degrees(np.arctan(d.uy_fark_cm/(100*d.B_m)))).max()),"training_row_count":len(d),"training_group_count":int(d.AnalizNo.nunique())}
    write_json(audit,outdir/"data_audit.json")
    write_table(d.groupby(["Senaryo","BinaKonumu"],sort=False).size().reset_index(name="n"),outdir/"scenario_position_counts.csv")
    print(f"Prepared {len(d)} observations / {d.AnalizNo.nunique()} analysis groups -> {outdir}",flush=True)
    return d


def grouped_cv(d,cfg,with_classifier=True):
    if d.AnalizNo.nunique()<cfg["n_splits"]:
        raise ValueError("Not enough independent AnalizNo groups for requested folds.")
    out=d.copy(); folds=[]; fit_warnings=[]
    for t in TARGETS: out[t+"_pred"]=np.nan
    out["fold"]=-1; out["high_response_probability"]=np.nan
    splitter=GroupKFold(n_splits=int(cfg["n_splits"]))
    for fold,(tr,te) in enumerate(splitter.split(d,d[DIRECT],d.AnalizNo),1):
        start=time.perf_counter()
        overlap=set(d.iloc[tr].AnalizNo)&set(d.iloc[te].AnalizNo)
        if overlap: raise AssertionError("Group leakage detected.")
        seed=int(cfg.get("cv_seed",cfg["random_state"]))+fold
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            model=fit_regressor(d.iloc[tr],cfg,seed)
        fit_warnings.extend({"fold":fold,"warning":str(w.message),"category":w.category.__name__} for w in caught)
        pred=predict_regressor(model,d.iloc[te],cfg)
        out.loc[te,pred.columns]=pred.values
        out.loc[te,"fold"]=fold
        if with_classifier:
            clf=fit_detector(d.iloc[tr],cfg,int(cfg.get("classifier_seed",1888))+fold)
            out.loc[te,"high_response_probability"]=detector_probability(clf,d.iloc[te])
        folds.append({"fold":fold,"seed":seed,"n_train":len(tr),"n_test":len(te),"train_groups":int(d.iloc[tr].AnalizNo.nunique()),"test_groups":int(d.iloc[te].AnalizNo.nunique()),"shared_groups":len(overlap),"elapsed_seconds":time.perf_counter()-start})
        print(f"Fold {fold}/{cfg['n_splits']}: train={len(tr)}, validation={len(te)}, shared AnalizNo=0",flush=True)
    if out[[t+"_pred" for t in TARGETS]].isna().any().any(): raise AssertionError("Incomplete OOF predictions.")
    out["high_response_flag"]=(out.high_response_probability>=cfg["classifier_probability_threshold"]).astype(int)
    return out,pd.DataFrame(folds),fit_warnings


def apply_q(d,qs,gated=False):
    out=d.copy()
    flag=out.get("high_response_flag",pd.Series(0,index=out.index)).astype(bool)
    for t in TARGETS:
        q=np.where(flag,qs[t]["upper_response"],qs[t]["global"]) if gated else qs[t]["global"]
        out[t+"_lo90"]=np.maximum(0.,out[t+"_pred"]-q)
        out[t+"_hi90"]=out[t+"_pred"]+q
    return out


def nested_interval_check(d,outer,cfg,inner_splits=3):
    """Evaluate intervals without using outer-fold outcomes for calibration.

    Each inner OOF residual table is learned only on the outer training groups.
    This is cross-fitted residual-band validation, NOT a claim of conformal
    coverage. The point-prediction folds remain those of the outer experiment.
    """
    result=outer.copy()
    meta=[]
    for fold in sorted(result.fold.unique()):
        tr=d.loc[outer.fold!=fold].reset_index(drop=True)
        ids=outer.index[outer.fold==fold]
        inner_cfg=deepcopy(cfg); inner_cfg["n_splits"]=min(inner_splits,tr.AnalizNo.nunique())
        inner,_,_=grouped_cv(tr,inner_cfg,with_classifier=False)
        qs,definition=residual_quantiles(inner,cfg)
        calibrated=apply_q(outer.loc[ids],qs,gated=True)
        for c in calibrated:
            if c.endswith(("_lo90","_hi90")):
                result.loc[ids,c]=calibrated[c].values
        meta.append({"outer_fold":int(fold),"calibration_groups":int(tr.AnalizNo.nunique()),"upper_definition_from_outer_train":definition,"quantiles":qs})
    return result,meta


def validate(input_path,outdir,cfg,nested_bands=False):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    d,events=load_training(input_path)
    oof,folds,fit_warnings=grouped_cv(d,cfg)
    qs,upper=residual_quantiles(oof,cfg)
    oof["upper_response_observed"]=upper_mask(oof,upper).astype(int)
    oof["high_response_observed"]=(oof.T_deg>cfg["high_response_T_deg"]).astype(int)
    write_table(oof,outdir/"oof_predictions.csv")
    write_table(folds,outdir/"fold_audit.csv")
    masks={"all":np.ones(len(d),bool),"upper_response_q90_union":upper_mask(oof,upper),"high_response_T_gt_5":oof.high_response_observed.eq(1)}
    write_table(regression_metrics(oof,masks=masks),outdir/"regression_metrics.csv")
    write_table(tolerance_metrics(oof,cfg),outdir/"tolerance_rates.csv")
    cov=[]
    for gated in [False,True]:
        calibrated=apply_q(oof,qs,gated=gated)
        cov.append(coverage_metrics(calibrated,"same_OOF_gated_diagnostic" if gated else "same_OOF_global_diagnostic"))
    write_table(pd.concat(cov,ignore_index=True),outdir/"calibration_diagnostics_NOT_independent.csv")
    from sklearn.metrics import precision_score, recall_score, f1_score
    thresholds=[]
    for thr in [.1,.2,.3,.4,.5,.6]:
        flag=oof.high_response_probability>=thr
        thresholds.append({"threshold":thr,"precision":precision_score(oof.high_response_observed,flag,zero_division=0),"recall":recall_score(oof.high_response_observed,flag,zero_division=0),"F1":f1_score(oof.high_response_observed,flag,zero_division=0),"interpretation":"threshold sensitivity, not threshold tuning on external cases"})
    write_table(pd.DataFrame(thresholds),outdir/"detector_threshold_sensitivity.csv")
    manifest={"release":__version__,"created_utc":datetime.now(timezone.utc).isoformat(),"config":cfg,"environment":environment(),"input_sha256":sha256(input_path),"canonical_signature":frame_signature(d),"rows":len(d),"groups":int(d.AnalizNo.nunique()),"upper_response_definition":upper,"high_response_definition":f"T_deg > {cfg['high_response_T_deg']}","residual_quantiles":qs,"nested_bands":nested_bands,"warnings":fit_warnings,"events":events,"method_notes":["Pooled OOF metrics are development estimates for a fixed chosen configuration, not an untouched external test.","Same-OOF coverage is calibration diagnostics, not independent interval validation.","Upper-response quantiles are descriptive; the high-response classifier predicts a different T>5 label."]}
    if nested_bands:
        nested,meta=nested_interval_check(d,oof,cfg)
        write_table(nested,outdir/"nested_interval_predictions.csv")
        write_table(coverage_metrics(nested,"outer_fold_validated_residual_bands"),outdir/"nested_interval_coverage.csv")
        write_json(meta,outdir/"nested_interval_calibration_details.json")
    write_json(manifest,outdir/"validation_manifest.json")
    print(f"Validation tables saved -> {outdir}",flush=True)
    return manifest


def train(input_path,validation_dir,out_path,cfg):
    d,_=load_training(input_path)
    vm=read_json(Path(validation_dir)/"validation_manifest.json")
    if vm["canonical_signature"]!=frame_signature(d):
        raise ValueError("Training data differ from the residual-calibration data. Run validate on this input first.")
    for key in sorted((set(vm["config"]) | set(cfg)) - {"n_jobs", "description", "release"}):
        if vm["config"].get(key)!=cfg.get(key):
            raise ValueError(f"Configuration {key} differs from validation. Re-run validation; do not reuse incompatible residual bands.")
    model=fit_regressor(d,cfg)
    clf=fit_detector(d,cfg)
    b={"schema_version":1,"release":__version__,"config":cfg,"point_model":model,"high_response_classifier":clf,"residual_quantiles":vm["residual_quantiles"],"upper_response_definition":vm["upper_response_definition"],"canonical_signature":frame_signature(d),"data_metadata":range_metadata(d),"environment":environment(),"training_rows":len(d),"training_groups":int(d.AnalizNo.nunique()),"band_provenance":"OOF diagnostic calibration; see validation_manifest.json","prediction_contract":"learn uy_min and delta; derive uy_max and T; no output-based model switching"}
    save_bundle(b,out_path)
    if hasattr(model, "named_steps") and hasattr(model.named_steps["model"], "feature_importances_"):
        write_table(pd.DataFrame({"encoded_feature":model.named_steps["pre"].get_feature_names_out(),"MDI_importance":model.named_steps["model"].feature_importances_}),Path(out_path).parent/"feature_importance_MDI.csv")
    print(f"Fitted final model ({cfg['n_estimators']} trees, seed={cfg['random_state']}) -> {out_path}",flush=True)
    return b


def predict(input_path,model_path,outdir,fmt="long",sheet=0,strict_cases=True,interval_mode=None):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    d,events=prepare_inputs(read_table(input_path,sheet),fmt,strict_cases)
    b=load_bundle(model_path)
    out=predict_bundle(b,d,interval_mode)
    write_table(out,outdir/"predictions.csv")
    write_json({"model_sha256":sha256(model_path),"input_sha256":sha256(input_path),"rows":len(out),"events":events,"mode":interval_mode or b["config"]["interval_mode"],"outside_marginal_ranges":int(out.outside_training_range_flag.sum()),"notes":["Input bounds are not a multivariate applicability guarantee.","Observed values were not used for prediction or band selection."]},outdir/"prediction_audit.json")
    return out


def evaluate(prediction_path,outdir,cfg):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    d=observed_reference(read_table(prediction_path))
    write_table(d,outdir/"all_case_results.csv")
    write_table(regression_metrics(d,source="external_case_study"),outdir/"external_metrics.csv")
    write_table(tolerance_metrics(d,cfg),outdir/"external_tolerance_rates.csv")
    write_table(coverage_metrics(d,"unchanged_model_diagnostic_bands"),outdir/"external_coverage.csv")
    bycase=[]
    if "CaseID" in d:
        for case,part in d.groupby("CaseID",sort=False):
            row=regression_metrics(part,source="external_case_study");row["CaseID"]=case;bycase.append(row)
        write_table(pd.concat(bycase,ignore_index=True),outdir/"per_case_metrics.csv")
    write_json({"rows_predicted":len(d),"rows_with_both_displacements":int((d.uy_min_cm.notna()&d.uy_max_cm.notna()).sum()),"qualitative_only":int(d.reference_status.eq("qualitative_only").sum()),"excluded_due_to_large_error":0,"selected_cases_for_figures_do_not_change_metrics":True,"source_sha256":sha256(prediction_path),"notes":["Unknown observations are not assumed to be true zero or known censored intervals.","All supplied cases remain visible. Marginal range violations are reported, not used to remove bad predictions.","Tolerance thresholds are descriptive sensitivity analyses; high tolerance rates are not nominal interval coverage."]},outdir/"external_evaluation_audit.json")
    print(f"External evaluation: {len(d)} predictions; all cases retained -> {outdir}",flush=True)
    return d
