"""Reproducible building-settlement modelling and complete-case evaluation."""
__version__ = "1.0.0"
