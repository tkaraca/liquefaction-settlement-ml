# Release execution checks

Local preparation date: 2026-09-17. Platform: Linux, Python 3.13.5. See `reference/checks/execution_environment.json`.

| Check | Observed result |
|---|---|
| Automated tests | **35 passed** |
| Compile source/run scripts | Passed |
| Preprocess released table | 2325 records; 1099 retained analysis groups |
| Original-layout XLSX + explicit historical QC | Same canonical training signature |
| Five-fold GroupKFold | Each row predicted once; zero shared AnalizNo in every train/validation split |
| Optional nested residual calibration | Completed; interval metrics recorded separately |
| Full-data refit versus archived frozen point model | Maximum external point discrepancy about 1.4e-14 cm |
| Archived OOF MAE recomputation | Maximum discrepancy 0 |
| Frozen model versus rounded archived external predictions | Maximum difference below 5.1e-5 |
| External case evaluation | 14 predictions; 12 numeric references; uncertain rows retained visibly |
| XLSX prediction template | All 6 example rows processed; cached H/B verified |
| Wide input expansion | 1 + 2 + 3 = 6 building rows |
| Excel Run button from non-repository working directory | Passed; 6 separate PNG/SVG charts |
| End-to-end CLI `all` | Passed; preprocess, CV, training, prediction, evaluation, plots |
| Feature ablation | 12 configurations completed |
| Target-transform/weight ablation | 8 configurations completed |
| ANN core ablation | 8 configurations completed, using resume after interruption; warnings preserved |
| Family benchmark | 10 configurations completed, including XGBoost, LightGBM, native CatBoost |
| Linear/spline coefficient baseline | Both GroupKFold comparisons executed |
| Executable coefficient JSON | Matches native pipeline, maximum discrepancy 5.68e-14 on 2325 rows |
| Output galleries | Validation and all-case plots generated in PNG/SVG and HTML |

Scientific limitations and historical/release differences are described in `docs/REPRODUCIBILITY.md` and `docs/MODEL_CARD.md`. Passing software tests does not prove field-generalization accuracy or interval-coverage guarantees.

The delivered hash manifest is checked by `python scripts/verify_release.py`. GitHub publication and remote CI runs were not performed. Runtime logs for completed experiments are in `reference/checks/logs/`.
