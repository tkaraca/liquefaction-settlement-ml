"""Run-button entry point. Uses paths relative to this file, not your IDE's working directory."""
from pathlib import Path
import os
import sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from settlementml.__main__ import main

if __name__ == "__main__":
    os.chdir(ROOT)
    main(["figures", "--run", "outputs/validation"])
    if (ROOT / "outputs/external/all_case_results.csv").exists():
        main(["figures", "--run", "outputs/external"])
