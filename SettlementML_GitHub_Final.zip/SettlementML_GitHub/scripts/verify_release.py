"""Verify delivered file hashes and model/data/reference consistency.

Run from any working directory: python /path/to/repository/scripts/verify_release.py
This script loads only the trusted bundled model, never downloads a model.
"""
from pathlib import Path
import hashlib
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def check_hashes():
    manifest = ROOT / 'HASHES.sha256'
    if not manifest.exists():
        raise RuntimeError('HASHES.sha256 missing: this is not the complete packaged release.')
    checked = 0
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        expected, relative = line.split('  ', 1)
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT):
            raise RuntimeError('Invalid relative path in hash manifest.')
        if not path.is_file():
            raise RuntimeError(f'Missing release file: {relative}')
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
        if h.hexdigest() != expected:
            raise RuntimeError(f'Changed/corrupted release file: {relative}. An intentional edit requires a new version/manifest.')
        checked += 1
    return checked


def main():
    checked = check_hashes()
    import numpy as np
    from settlementml.io import read_table, read_json
    from settlementml.data import training_table, prepare_inputs, TARGETS
    from settlementml.models import load_bundle, predict_bundle
    from settlementml.metrics import regression_metrics, observed_reference, coverage_metrics
    from settlementml.workflows import frame_signature
    train = training_table(read_table(ROOT / 'data/training_qc.csv'))[0]
    bundle = load_bundle(ROOT / 'models/final.joblib')
    cfg = read_json(ROOT / 'configs/final.json')
    assert len(train) == bundle['training_rows'] == 2325
    assert train.AnalizNo.nunique() == bundle['training_groups'] == 1099
    assert frame_signature(train) == bundle['canonical_signature']
    fitted = bundle['point_model'].named_steps['model']
    assert fitted.n_estimators == cfg['n_estimators'] == 60
    assert fitted.random_state == cfg['random_state'] == 1777
    d, _ = prepare_inputs(read_table(ROOT / 'data/examples/external_cases.csv'))
    pred = predict_bundle(bundle, d)
    archived = read_table(ROOT / 'reference/archived_external_predictions.csv')
    differences = {}
    pairs = {'uy_min_cm_pred': 'pred_uy_min_cm', 'uy_fark_cm_pred': 'pred_delta_uy_cm',
             'uy_max_cm_pred': 'pred_uy_max_cm', 'T_deg_pred': 'pred_T_deg'}
    for current, old in pairs.items():
        delta = float(np.max(abs(pred[current].to_numpy() - archived[old].to_numpy())))
        assert delta <= 5.1e-5, (current, delta)
        differences[current] = delta
    evaluation = observed_reference(pred)
    cov = coverage_metrics(evaluation).set_index('target')
    assert len(evaluation) == 14
    assert cov.loc['uy_min_cm', 'n'] == 12
    assert cov.loc['uy_min_cm', 'inside'] == 3
    assert cov.loc['uy_max_cm', 'inside'] == 5
    assert cov.loc['T_deg', 'inside'] == 6
    historical = regression_metrics(read_table(ROOT / 'reference/archived_core_oof.csv'))
    report = read_table(ROOT / 'reference/archived_report_metrics.csv')
    historical_errors = {}
    for _, row in report.iterrows():
        value = historical.loc[historical.target.eq(row.Target), 'MAE'].iloc[0]
        difference = float(abs(value - row.MAE))
        assert difference < 1e-10
        historical_errors[row.Target] = difference
    print(json.dumps({'status': 'PASS', 'hashed_files': checked, 'training_rows': len(train),
                      'retained_groups': int(train.AnalizNo.nunique()), 'external_predictions': len(pred),
                      'numeric_external_references': 12,
                      'frozen_vs_rounded_external_max_difference': differences,
                      'archived_MAE_recomputation_difference': historical_errors,
                      'note': 'Historical metric recomputation is separate from newly fitted OOF models.'}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        sys.exit(f'RELEASE CHECK FAILED: {exc}')
