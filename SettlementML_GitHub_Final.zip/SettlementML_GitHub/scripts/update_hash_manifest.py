"""Create hashes after an intentional, documented repository revision.

Do not use this to hide a failed integrity check of a downloaded release.
"""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
SKIP = {'.git', '.venv', 'outputs', '__pycache__', '.pytest_cache', 'build', 'dist', '.mypy_cache'}

if __name__ == '__main__':
    lines=[]
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if not path.is_file() or set(rel.parts) & SKIP or path.name == 'HASHES.sha256' or path.suffix in {'.pyc','.pyo'}:
            continue
        if any(part.endswith('.egg-info') for part in rel.parts):
            continue
        h=hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f'{h}  {rel.as_posix()}')
    (ROOT/'HASHES.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Wrote hashes for {len(lines)} files. Record the corresponding revision in CHANGELOG.md.')
