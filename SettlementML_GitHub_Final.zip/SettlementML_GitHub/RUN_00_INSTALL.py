"""Run in the Python interpreter/environment you intend to use for this project."""
from pathlib import Path
import subprocess
import sys
if __name__=="__main__":
    root=Path(__file__).resolve().parent
    print("Installing into:",sys.executable)
    subprocess.run([sys.executable,"-m","pip","install","-r",str(root/"requirements.txt")],check=True)
