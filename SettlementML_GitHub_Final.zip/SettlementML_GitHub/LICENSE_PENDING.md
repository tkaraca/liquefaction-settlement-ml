# License decision pending

No code, data or trained-model license has been selected on behalf of the research team. The package is delivered to the requesting project team for review and reproducibility. Before making the repository public, the rights holders should select and include the intended license(s), verify data redistribution permissions and replace this notice as appropriate.

The license status of third-party libraries remains governed by their respective licenses. Their installation through requirements files does not transfer ownership of project data or authorize its redistribution.
